/* ═══════════════════════════════════════════
   report.js — Advanced Report Screen
   ═══════════════════════════════════════════ */

/* ── Report Config Panel ── */
function ReportConfigPanel({ config, setConfig, onClose, t }) {
  const update = (key, val) => setConfig(prev => ({ ...prev, [key]: val }));

  const Section = ({ title, children }) => (
    <div style={{ marginBottom:16, borderBottom:"1px solid rgba(255,255,255,0.1)", paddingBottom:12 }}>
      <div style={{ fontSize:11, fontWeight:800, color:"#C8973A", marginBottom:10, letterSpacing:1 }}>{title}</div>
      <div style={{ display:"flex", flexDirection:"column", gap:10 }}>{children}</div>
    </div>
  );

  const Row = ({ label, checked, onChange, subLabel }) => (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
      <div>
        <div style={{ fontSize:12, fontWeight:600, color:"#F5EDD6" }}>{label}</div>
        {subLabel && <div style={{ fontSize:10, color:"#706050" }}>{subLabel}</div>}
      </div>
      <label className="toggle-switch">
        <input type="checkbox" checked={checked} onChange={e => onChange(e.target.checked)}/>
        <span className="slider"></span>
      </label>
    </div>
  );

  return (
    <div style={{ position:"fixed", inset:0, zIndex:600, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"flex-end", justifyContent:"center" }} className="backdrop-blur" onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{ background:"#1A1810", borderTop:"2px solid #C8973A", borderRadius:"20px 20px 0 0", width:"100%", maxWidth:500, maxHeight:"85vh", overflowY:"auto", padding:"20px" }}>
        <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:20 }}>
          <h3 style={{ margin:0, fontSize:16, fontWeight:800, color:"#F0C060" }}>{t.configTitle}</h3>
          <button onClick={onClose} style={{ background:"none", border:"none", color:"#706050", fontSize:20, cursor:"pointer" }}>✕</button>
        </div>

        <Section title={t.secData}>
          <Row label={t.hideZero}         checked={config.hideZeroItems}       onChange={v => update('hideZeroItems', v)}/>
          <Row label={t.excludeZeroDays}  checked={config.excludeZeroDays}     onChange={v => update('excludeZeroDays', v)}/>
          <Row label={t.groupSmall}       checked={config.groupSmallExpenses}  onChange={v => update('groupSmallExpenses', v)} subLabel={`${t.threshold} ${config.smallExpenseThreshold}€`}/>
          {config.groupSmallExpenses && (
            <input type="number" value={config.smallExpenseThreshold} onChange={e => update('smallExpenseThreshold', Number(e.target.value))} style={{ width:"100%", padding:8, background:"rgba(255,255,255,0.05)", border:"1px solid #C8973A", borderRadius:6, color:"#fff", fontSize:12 }}/>
          )}
        </Section>

        <Section title={t.secAnalysis}>
          <Row label={t.showKPIs}     checked={config.showKPIs}            onChange={v => update('showKPIs', v)}/>
          <Row label={t.showComp}     checked={config.showComparison}      onChange={v => update('showComparison', v)}/>
          <Row label={t.showCharts}   checked={config.showCharts}          onChange={v => update('showCharts', v)}/>
          <Row label={t.showBranch}   checked={config.showBranchAnalysis}  onChange={v => update('showBranchAnalysis', v)}/>
          <Row label={t.showPlatform} checked={config.showPlatformAnalysis} onChange={v => update('showPlatformAnalysis', v)}/>
          <Row label={t.setTarget}    checked={config.salesTarget > 0}     onChange={v => update('salesTarget', v ? 15000 : 0)}/>
          {config.salesTarget > 0 && (
            <input type="number" value={config.salesTarget} onChange={e => update('salesTarget', Number(e.target.value))} style={{ width:"100%", padding:8, background:"rgba(255,255,255,0.05)", border:"1px solid #3AC87D", borderRadius:6, color:"#fff", fontSize:12 }}/>
          )}
        </Section>

        <Section title={t.secSort}>
          <div style={{ fontSize:12, color:"#F5EDD6", marginBottom:4 }}>{t.sortBranch}</div>
          <select value={config.branchSort} onChange={e => update('branchSort', e.target.value)} style={{ width:"100%", padding:8, background:"#0F0E0A", border:"1px solid #333", borderRadius:6, color:"#fff", fontSize:12, marginBottom:10 }}>
            <option value="profit">{t.sortProfit}</option>
            <option value="sales">{t.sortSales}</option>
            <option value="alpha">{t.sortAlpha}</option>
          </select>
          <Row label={t.sortItems} checked={config.itemSort==='value_desc'} onChange={v => update('itemSort', v ? 'value_desc' : 'fixed')}/>
        </Section>

        <Section title={t.secVisual}>
          <Row label={t.printLight} checked={config.printMode==='light'} onChange={v => update('printMode', v ? 'light' : 'dark')}/>
          <Row label={t.showPct}    checked={config.showPercentages}     onChange={v => update('showPercentages', v)}/>
          <Row label={t.showIcons}  checked={config.showIcons}           onChange={v => update('showIcons', v)}/>
          <Row label={t.showCurr}   checked={config.showCurrency}        onChange={v => update('showCurrency', v)}/>
          <Row label={t.watermark}  checked={config.watermark !== 'none'} onChange={v => update('watermark', v ? 'confidential' : 'none')}/>
          <Row label={t.showNotes}  checked={config.showManualNotes}     onChange={v => update('showManualNotes', v)}/>
        </Section>

        <button onClick={onClose} style={{ ...btn("linear-gradient(135deg,#C8973A,#A67828)","none","#0F0E0A",{width:"100%",marginTop:10,border:"none",padding:12}) }}>✓ {t.saveBtn}</button>
      </div>
    </div>
  );
}

/* ── Advanced Report Screen ── */
function AdvancedReport({ data, branches, t, isAr, onClose, restName }) {
  const initialDate = now();
  const [selYear,    setSelYear]   = useState(initialDate.year);
  const [selMonth,   setSelMonth]  = useState(initialDate.month);
  const [config,     setConfig]    = useState(DEFAULT_REPORT_CONFIG);
  const [showConfig, setShowConfig] = useState(false);

  /* ── Date range helpers ── */
  const dim      = new Date(selYear, selMonth, 0).getDate();
  const keys     = Array.from({ length:dim }, (_, i) => dKey(selYear, selMonth, i+1));
  const prevMonth = selMonth===1 ? 12 : selMonth-1;
  const prevYear  = selMonth===1 ? selYear-1 : selYear;
  const prevDim   = new Date(prevYear, prevMonth, 0).getDate();
  const prevKeys  = Array.from({ length:prevDim }, (_, i) => dKey(prevYear, prevMonth, i+1));

  const sumAll = (sec, sub, kArray=keys) =>
    branches.reduce((a, b) => a + kArray.reduce((aa, k) => aa + ((data[b.id]?.[k]?.[sec]?.[sub])||0), 0), 0);
  const sumB = (bid, sec, sub, kArray=keys) =>
    kArray.reduce((a, k) => a + ((data[bid]?.[k]?.[sec]?.[sub])||0), 0);

  /* ── Totals ── */
  const ts = sumAll("sales","direct") + sumAll("sales","glovo_net") + sumAll("sales","uberEats_net") + sumAll("sales","lastApp");
  const tp = sumAll("purchases","meat") + sumAll("purchases","mercadona") + sumAll("purchases","macro") + sumAll("purchases","veg") + sumAll("purchases","baklawa") + sumAll("purchases","bread");
  const te = sumAll("expenses","rent") + sumAll("expenses","electricity") + sumAll("expenses","salaries") + sumAll("expenses","water") + sumAll("expenses","other");
  const profit = ts - tp - te;

  /* ── Previous month totals ── */
  const pts = sumAll("sales","direct",prevKeys) + sumAll("sales","glovo_net",prevKeys) + sumAll("sales","uberEats_net",prevKeys) + sumAll("sales","lastApp",prevKeys);
  const ptp = sumAll("purchases","meat",prevKeys) + sumAll("purchases","mercadona",prevKeys) + sumAll("purchases","macro",prevKeys) + sumAll("purchases","veg",prevKeys) + sumAll("purchases","baklawa",prevKeys) + sumAll("purchases","bread",prevKeys);
  const pte = sumAll("expenses","rent",prevKeys) + sumAll("expenses","electricity",prevKeys) + sumAll("expenses","salaries",prevKeys) + sumAll("expenses","water",prevKeys) + sumAll("expenses","other",prevKeys);
  const pProfit = pts - ptp - pte;

  const Trend = ({ curr, prev }) => {
    if (prev===0) return null;
    const p = (((curr-prev)/Math.abs(prev))*100).toFixed(1);
    return <span style={{ fontSize:10, fontWeight:700, color: curr>=prev?"#3AC87D":"#C83A3A" }} className="western-numerals">({p>0?"+":""}{p}%)</span>;
  };

  /* ── Branch data ── */
  let branchData = branches.map(b => {
    const bs = sumB(b.id,"sales","direct") + sumB(b.id,"sales","glovo_net") + sumB(b.id,"sales","uberEats_net") + sumB(b.id,"sales","lastApp");
    const bp = sumB(b.id,"purchases","meat") + sumB(b.id,"purchases","mercadona") + sumB(b.id,"purchases","macro") + sumB(b.id,"purchases","veg") + sumB(b.id,"purchases","baklawa") + sumB(b.id,"purchases","bread");
    const be = sumB(b.id,"expenses","rent") + sumB(b.id,"expenses","electricity") + sumB(b.id,"expenses","salaries") + sumB(b.id,"expenses","water") + sumB(b.id,"expenses","other");
    return { ...b, sales:bs, purchases:bp, expenses:be, profit:bs-bp-be };
  });
  if (config.branchSort==='profit') branchData.sort((a,b) => b.profit-a.profit);
  else if (config.branchSort==='sales') branchData.sort((a,b) => b.sales-a.sales);
  else branchData.sort((a,b) => a.nameEn.localeCompare(b.nameEn));

  /* ── Platform data ── */
  const platforms = [
    { name:t.glovo,    gross:sumAll("sales","glovo"),    net:sumAll("sales","glovo_net"),    ad:0,                           color:"#FF6B00" },
    { name:t.uberEats, gross:sumAll("sales","uberEats"), net:sumAll("sales","uberEats_net"), ad:sumAll("sales","uberEats_ad"), color:"#06C167" },
    { name:t.lastApp,  gross:sumAll("sales","lastApp"),  net:sumAll("sales","lastApp"),      ad:0,                           color:"#0084FF" }
  ].filter(p => config.hideZeroItems ? (p.gross>0) : true);

  /* ── Detail items ── */
  let detailItems = [
    { label:t.directSales, val:sumAll("sales","direct"), cat:"sales", color:"#C8973A", icon:"🏪" },
    ...platforms.map(p => ({ label:`${p.name} (Net)`, val:p.net, cat:"sales", color:p.color, icon:"📱" })),
    { label:t.meat,        val:sumAll("purchases","meat"),        cat:"purchases", color:"#C83A3A", icon:"🥩" },
    { label:t.mercadona,   val:sumAll("purchases","mercadona"),   cat:"purchases", color:"#3A7DC8", icon:"🏬" },
    { label:t.macro,       val:sumAll("purchases","macro"),       cat:"purchases", color:"#8B3AC8", icon:"📦" },
    { label:t.veg,         val:sumAll("purchases","veg"),         cat:"purchases", color:"#3AC87D", icon:"🥬" },
    { label:t.baklawa,     val:sumAll("purchases","baklawa"),     cat:"purchases", color:"#C8973A", icon:"🍯" },
    { label:t.bread,       val:sumAll("purchases","bread"),       cat:"purchases", color:"#C8683A", icon:"🍞" },
    { label:t.rent,        val:sumAll("expenses","rent"),         cat:"expenses",  color:"#C83A3A", icon:"🏠" },
    { label:t.electricity, val:sumAll("expenses","electricity"),  cat:"expenses",  color:"#C8C03A", icon:"⚡" },
    { label:t.salaries,    val:sumAll("expenses","salaries"),     cat:"expenses",  color:"#3AC87D", icon:"👥" },
    { label:t.water,       val:sumAll("expenses","water"),        cat:"expenses",  color:"#3A7DC8", icon:"💧" },
    { label:t.other,       val:sumAll("expenses","other"),        cat:"expenses",  color:"#8B3AC8", icon:"📋" }
  ];
  let finalItems = config.hideZeroItems ? detailItems.filter(i => i.val>0) : detailItems;
  if (config.itemSort==='value_desc') finalItems.sort((a,b) => b.val-a.val);
  if (config.groupSmallExpenses) {
    const small = finalItems.filter(i => i.val>0 && i.val<config.smallExpenseThreshold);
    const smallTotal = small.reduce((acc,i) => acc+i.val, 0);
    finalItems = finalItems.filter(i => i.val>=config.smallExpenseThreshold || i.val===0);
    if (smallTotal>0) finalItems.push({ label: isAr?"مصروفات/مشتريات نثرية":"Misc. Expenses/Purchases", val:smallTotal, cat:"grouped", color:"#706050", icon:"📎" });
  }

  /* ── Export ── */
  const handleExport = (type) => {
    const isLight  = config.printMode==='light';
    const bg       = isLight ? "#ffffff" : "#0F0E0A";
    const text     = isLight ? "#1a1a1a" : "#F5EDD6";
    const border   = isLight ? "#e0e0e0" : "rgba(255,255,255,0.1)";
    const cardBg   = isLight ? "#f9f9f9" : "rgba(255,255,255,0.03)";
    const wmCSS    = config.watermark!=='none' ? `body::before{content:"${config.watermark==='confidential'?(isAr?'سري جداً':'CONFIDENTIAL'):(isAr?'مسودة':'DRAFT')}";position:fixed;top:50%;left:50%;transform:translate(-50%,-50%) rotate(-45deg);font-size:80px;color:rgba(200,0,0,0.08);font-weight:900;pointer-events:none;z-index:0;}` : '';

    let html = `<!DOCTYPE html><html dir="${isAr?'rtl':'ltr'}"><head><meta charset="utf-8"><title>${restName}</title>
<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700;800&display=swap" rel="stylesheet">
<style>body{font-family:'Cairo',sans-serif;background:${bg};color:${text};padding:40px;direction:${isAr?'rtl':'ltr'};margin:0;}${wmCSS}.header{text-align:center;border-bottom:2px solid #C8973A;padding-bottom:20px;margin-bottom:30px;}.header h1{color:#C8973A;margin:0;font-size:28px;}.kpi-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:15px;margin-bottom:30px;}.kpi-card{background:${cardBg};border:1px solid ${border};border-radius:8px;padding:15px;text-align:center;}.kpi-label{font-size:11px;color:#888;margin-bottom:5px;}.kpi-val{font-size:20px;font-weight:800;color:#C8973A;}table{width:100%;border-collapse:collapse;margin-bottom:25px;font-size:13px;}th{background:#C8973A;color:#fff;padding:10px;text-align:${isAr?'right':'left'};font-weight:700;}td{padding:8px 10px;border-bottom:1px solid ${border};}tr:nth-child(even){background:${isLight?'#fdfdfd':'rgba(255,255,255,0.02)'};}.footer{margin-top:40px;border-top:1px solid ${border};padding-top:15px;text-align:center;font-size:11px;color:#888;display:flex;justify-content:space-between;}@media print{body{padding:20px;-webkit-print-color-adjust:exact;print-color-adjust:exact;}}</style></head><body>`;

    html += `<div class="header"><h1>${restName}</h1><p>${t.reportTitle} — ${t.months[selMonth-1]} ${selYear}</p></div>`;

    if (config.showKPIs) {
      html += `<div class="kpi-grid">
        <div class="kpi-card"><div class="kpi-label">${t.salesBtn} (Net)</div><div class="kpi-val">${fmt(ts,config.showCurrency)}</div></div>
        <div class="kpi-card"><div class="kpi-label">${t.purchasesBtn}</div><div class="kpi-val" style="color:#3A7DC8">${fmt(tp,config.showCurrency)}</div></div>
        <div class="kpi-card"><div class="kpi-label">${t.expensesBtn}</div><div class="kpi-val" style="color:#C83A3A">${fmt(te,config.showCurrency)}</div></div>
        <div class="kpi-card"><div class="kpi-label">${t.profit}</div><div class="kpi-val" style="color:${profit>=0?'#3AC87D':'#C83A3A'}">${fmt(profit,config.showCurrency)}</div></div>
      </div>`;
    }

    if (config.showBranchAnalysis) {
      html += `<h3 style="color:#C8973A;">📊 ${t.compareBranches}</h3><table><tr><th>${t.branches}</th><th>${t.salesBtn}</th><th>${t.purchasesBtn}</th><th>${t.expensesBtn}</th><th>${t.profit}</th><th>Margin</th></tr>`;
      branchData.forEach(b => {
        const margin = b.sales>0 ? ((b.profit/b.sales)*100).toFixed(1) : 0;
        html += `<tr><td>${b.icon} ${b.nameEn}</td><td>${fmt(b.sales,config.showCurrency)}</td><td>${fmt(b.purchases,config.showCurrency)}</td><td>${fmt(b.expenses,config.showCurrency)}</td><td style="color:${b.profit>=0?'#3AC87D':'#C83A3A'};font-weight:700">${fmt(b.profit,config.showCurrency)}</td><td>${margin}%</td></tr>`;
      });
      html += `</table>`;
    }

    if (config.showPlatformAnalysis) {
      html += `<h3 style="color:#C8973A;">📱 ${t.onlineSales}</h3><table><tr><th>${isAr?'المنصة':'Platform'}</th><th>Broto</th><th>Neto</th><th>${isAr?'العمولة':'Commission'}</th><th>Ads</th></tr>`;
      platforms.forEach(p => {
        html += `<tr><td>${p.name}</td><td>${fmt(p.gross,config.showCurrency)}</td><td>${fmt(p.net,config.showCurrency)}</td><td>${fmt(p.gross-p.net-p.ad,config.showCurrency)}</td><td>${fmt(p.ad,config.showCurrency)}</td></tr>`;
      });
      html += `</table>`;
    }

    html += `<h3 style="color:#C8973A;">📋 ${isAr?'التفاصيل المالية':'Financial Details'}</h3><table><tr><th>${isAr?'البند':'Item'}</th><th>${isAr?'المبلغ':'Amount'}</th></tr>`;
    finalItems.forEach(i => {
      if (i.val>0 || !config.hideZeroItems)
        html += `<tr><td>"${config.showIcons?i.icon+' ':''}${i.label}"</td><td style="font-weight:700;color:${i.color}">${fmt(i.val,config.showCurrency)}</td></tr>`;
    });
    html += `<tr style="font-weight:800;"><td>${t.profit}</td><td style="color:${profit>=0?'#3AC87D':'#C83A3A'}">${fmt(profit,config.showCurrency)}</td></tr></table>`;

    if (config.showManualNotes && config.manualNotesText)
      html += `<div style="border:1px dashed ${border};padding:15px;border-radius:8px;font-size:12px;"><strong>${isAr?'ملاحظات':'Notes'}:</strong><br>${config.manualNotesText.replace(/\r?\n/g,'<br>')}</div>`;

    html += `<div class="footer"><span>${isAr?'تم الإنشاء':'Generated'}: ${new Date().toLocaleString()}</span><span>La Shawermeria</span></div></body></html>`;

    if (type==='pdf' || type==='print') {
      const blob = new Blob([html], { type:"text/html;charset=utf-8" });
      const url  = URL.createObjectURL(blob);
      const old  = document.getElementById("__print_frame__");
      if (old) { URL.revokeObjectURL(old.dataset.blobUrl||""); old.remove(); }
      const iframe = document.createElement("iframe");
      iframe.id = "__print_frame__"; iframe.dataset.blobUrl = url;
      iframe.style.cssText = "position:fixed;left:-9999px;top:0;width:1px;height:1px;";
      iframe.src = url; document.body.appendChild(iframe);
      iframe.onload = () => {
        try { iframe.contentWindow.focus(); iframe.contentWindow.print(); }
        catch(e) { window.open(url,"_blank"); }
        setTimeout(() => { URL.revokeObjectURL(url); if(iframe.parentNode) iframe.remove(); }, 30000);
        iframe.contentWindow.onafterprint = () => { URL.revokeObjectURL(url); if(iframe.parentNode) iframe.remove(); };
      };
    } else if (type==='csv') {
      let csv = "\uFEFF" + (isAr?"البند,الفئة,المبلغ\n":"Item,Category,Amount\n");
      finalItems.forEach(i => { if(i.val>0||!config.hideZeroItems) csv += `"${i.label}","${i.cat}",${i.val}\n`; });
      const blob = new Blob([csv],{type:'text/csv;charset=utf-8;'});
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a'); a.href=url; a.download=`Report_${selYear}_${selMonth}.csv`; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    }
  };

  const changeMonth = (dir) => {
    let nm=selMonth+dir, ny=selYear;
    if (nm>12){nm=1; ny++;} if (nm<1){nm=12; ny--;}
    setSelMonth(nm); setSelYear(ny);
  };

  const isLight  = config.printMode==='light';
  const cardBorder = isLight ? "#e0e0e0" : "rgba(255,255,255,0.07)";
  const cardBg     = isLight ? "#fff"    : "rgba(255,255,255,0.03)";

  return (
    <div style={{ position:"fixed", inset:0, zIndex:400, background: isLight?"#f4f4f4":"#0F0E0A", display:"flex", flexDirection:"column", direction:t.dir, fontFamily:"'Cairo',sans-serif" }}>
      {/* ── Toolbar ── */}
      <div className="no-print" style={{ borderBottom:"1px solid rgba(200,151,58,0.15)", padding:"14px", flexShrink:0, background: isLight?"#fff":"#0F0E0A" }}>
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:10 }}>
          <button onClick={onClose} style={{ ...btn("rgba(200,60,60,0.1)","rgba(200,60,60,0.3)","#C84040",{padding:"0",width:34,height:34,fontSize:16}) }}>✕</button>
          <div style={{ display:"flex", alignItems:"center", gap:12 }}>
            <button onClick={() => changeMonth(-1)} style={{ ...btn("rgba(255,255,255,0.05)","rgba(255,255,255,0.1)","#F5EDD6",{padding:"0 10px",height:34}) }}>‹</button>
            <div style={{ textAlign:"center", minWidth:120 }}>
              <div style={{ fontSize:16, fontWeight:800, color:"#F0C060" }}>{t.months[selMonth-1]} {selYear}</div>
            </div>
            <button onClick={() => changeMonth(1)} style={{ ...btn("rgba(255,255,255,0.05)","rgba(255,255,255,0.1)","#F5EDD6",{padding:"0 10px",height:34}) }}>›</button>
          </div>
          <div style={{ display:"flex", gap:6 }}>
            <button onClick={() => setShowConfig(true)}      style={{ ...btn("rgba(200,151,58,0.1)","rgba(200,151,58,0.3)","#C8973A",{padding:"0 12px",height:34,fontSize:11}) }}>⚙️ {isAr?'تخصيص':'Config'}</button>
            <button onClick={() => handleExport('pdf')}      style={{ ...btn("rgba(58,200,125,0.1)","rgba(58,200,125,0.3)","#3AC87D",{padding:"0 12px",height:34,fontSize:11}) }}>🖨 PDF</button>
            <button onClick={() => handleExport('csv')}      style={{ ...btn("rgba(58,125,200,0.1)","rgba(58,125,200,0.3)","#3A7DC8",{padding:"0 12px",height:34,fontSize:11}) }}>📊 CSV</button>
          </div>
        </div>
      </div>

      {/* ── Body ── */}
      <div style={{ flex:1, overflowY:"auto", padding:"20px", maxWidth:900, margin:"0 auto", width:"100%" }} className="report-container">
        {/* KPIs */}
        {config.showKPIs && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(140px,1fr))", gap:12, marginBottom:24 }}>
            {[{ l:t.salesBtn+" (Net)", v:ts, c:"#C8973A", prev:pts }, { l:t.purchasesBtn, v:tp, c:"#3A7DC8", prev:ptp }, { l:t.expensesBtn, v:te, c:"#C83A3A", prev:pte }, { l:t.profit, v:profit, c:profit>=0?"#3AC87D":"#C83A3A", prev:pProfit }].map((k,i) => (
              <div key={i} style={{ background:cardBg, border:`1px solid ${cardBorder}`, borderRadius:10, padding:14, textAlign:"center" }}>
                <div style={{ fontSize:10, color:"#706050", marginBottom:6, display:"flex", justifyContent:"center", alignItems:"center", gap:4 }}>
                  {k.l} {config.showComparison && <Trend curr={k.v} prev={k.prev}/>}
                </div>
                <div style={{ fontSize:18, fontWeight:900, color:k.c }} className="western-numerals">{fmt(k.v,config.showCurrency)}</div>
              </div>
            ))}
          </div>
        )}

        {/* Sales Target */}
        {config.salesTarget > 0 && (
          <div style={{ background: isLight?"#fff":"rgba(58,200,125,0.05)", border:"1px solid rgba(58,200,125,0.2)", borderRadius:10, padding:14, marginBottom:24 }}>
            <div style={{ display:"flex", justifyContent:"space-between", fontSize:11, marginBottom:6, fontWeight:700 }}>
              <span>🎯 {t.setTarget}: {fmt(config.salesTarget,config.showCurrency)}</span>
              <span style={{ color: ts>=config.salesTarget?"#3AC87D":"#C8973A" }}>{((ts/config.salesTarget)*100).toFixed(1)}% {isAr?'محقق':'Achieved'}</span>
            </div>
            <div style={{ height:8, background:"rgba(0,0,0,0.1)", borderRadius:4, overflow:"hidden" }}>
              <div style={{ height:"100%", width:`${Math.min((ts/config.salesTarget)*100,100)}%`, background: ts>=config.salesTarget?"#3AC87D":"#C8973A", transition:"width 0.5s" }}/>
            </div>
          </div>
        )}

        {/* Charts */}
        {config.showCharts && (
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:24 }}>
            <div style={{ background:cardBg, border:`1px solid ${cardBorder}`, borderRadius:10, padding:14 }}>
              <div style={{ fontSize:11, fontWeight:700, color:"#706050", marginBottom:10 }}>{isAr?'توزيع المبيعات':'Sales Distribution'}</div>
              {platforms.filter(p=>p.net>0).map(p => (
                <div key={p.name} style={{ marginBottom:8 }}>
                  <div style={{ display:"flex", justifyContent:"space-between", fontSize:10, marginBottom:3 }}>
                    <span>{p.name}</span>
                    <span className="western-numerals">{((p.net/ts)*100).toFixed(1)}%</span>
                  </div>
                  <div style={{ height:6, background:"rgba(0,0,0,0.1)", borderRadius:3 }}>
                    <div style={{ height:"100%", width:`${(p.net/ts)*100}%`, background:p.color, borderRadius:3 }}/>
                  </div>
                </div>
              ))}
            </div>
            <div style={{ background:cardBg, border:`1px solid ${cardBorder}`, borderRadius:10, padding:14 }}>
              <div style={{ fontSize:11, fontWeight:700, color:"#706050", marginBottom:10 }}>{isAr?'أفضل 3 فروع (ربحاً)':'Top 3 Branches (Profit)'}</div>
              {branchData.slice(0,3).map((b,i) => (
                <div key={b.id} style={{ display:"flex", justifyContent:"space-between", alignItems:"center", padding:"6px 0", borderBottom: i<2?"1px solid rgba(255,255,255,0.05)":"none" }}>
                  <span style={{ fontSize:11, fontWeight:600 }}>{i+1}. {b.icon} {b.nameEn}</span>
                  <span style={{ fontSize:12, fontWeight:800, color: b.profit>=0?"#3AC87D":"#C83A3A" }} className="western-numerals">{fmt(b.profit,config.showCurrency)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Branch table */}
        {config.showBranchAnalysis && (
          <div style={{ marginBottom:24, background:cardBg, borderRadius:10, overflow:"hidden", border:`1px solid ${cardBorder}` }}>
            <div style={{ padding:"12px 16px", background:"rgba(200,151,58,0.1)", borderBottom:"1px solid rgba(200,151,58,0.2)", fontSize:12, fontWeight:800, color:"#C8973A" }}>📊 {t.compareBranches}</div>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
              <thead>
                <tr style={{ background: isLight?"#f9f9f9":"rgba(255,255,255,0.03)" }}>
                  {[t.branches,t.salesBtn,t.purchasesBtn,t.expensesBtn,t.profit].map((h,i) => (
                    <th key={i} style={{ padding:10, textAlign:isAr?"right":"left", fontWeight:700, color:"#706050" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {branchData.map(b => (
                  <tr key={b.id} style={{ borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
                    <td style={{ padding:10, fontWeight:700 }}>{b.icon} {b.nameEn}</td>
                    <td style={{ padding:10, color:"#C8973A"  }} className="western-numerals">{fmt(b.sales,    config.showCurrency)}</td>
                    <td style={{ padding:10, color:"#3A7DC8"  }} className="western-numerals">{fmt(b.purchases,config.showCurrency)}</td>
                    <td style={{ padding:10, color:"#C83A3A"  }} className="western-numerals">{fmt(b.expenses, config.showCurrency)}</td>
                    <td style={{ padding:10, fontWeight:800, color: b.profit>=0?"#3AC87D":"#C83A3A" }} className="western-numerals">{fmt(b.profit,config.showCurrency)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Detail table */}
        <div style={{ background:cardBg, borderRadius:10, overflow:"hidden", border:`1px solid ${cardBorder}` }}>
          <div style={{ padding:"12px 16px", background:"rgba(200,151,58,0.1)", borderBottom:"1px solid rgba(200,151,58,0.2)", fontSize:12, fontWeight:800, color:"#C8973A" }}>📋 {isAr?'التفاصيل المالية':'Financial Details'}</div>
          <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
            <thead>
              <tr style={{ background: isLight?"#f9f9f9":"rgba(255,255,255,0.03)" }}>
                <th style={{ padding:10, textAlign:isAr?"right":"left", fontWeight:700, color:"#706050" }}>{isAr?'البند':'Item'}</th>
                <th style={{ padding:10, textAlign:isAr?"right":"left", fontWeight:700, color:"#706050" }}>{isAr?'المبلغ':'Amount'}</th>
                {config.showPercentages && <th style={{ padding:10, textAlign:isAr?"right":"left", fontWeight:700, color:"#706050" }}>%</th>}
              </tr>
            </thead>
            <tbody>
              {finalItems.map((item, idx) => {
                if (config.hideZeroItems && item.val===0) return null;
                const pct = ts>0&&item.cat==='sales' ? ((item.val/ts)*100).toFixed(1) : tp>0&&item.cat==='purchases' ? ((item.val/tp)*100).toFixed(1) : te>0&&item.cat==='expenses' ? ((item.val/te)*100).toFixed(1) : 0;
                return (
                  <tr key={idx} style={{ borderBottom:"1px solid rgba(255,255,255,0.05)" }}>
                    <td style={{ padding:10, fontWeight:600 }}>{config.showIcons && item.icon} {item.label}</td>
                    <td style={{ padding:10, fontWeight:700, color:item.color }} className="western-numerals">{fmt(item.val,config.showCurrency)}</td>
                    {config.showPercentages && <td style={{ padding:10, fontSize:10, color:"#706050" }} className="western-numerals">{pct}%</td>}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Manual notes */}
        {config.showManualNotes && (
          <div style={{ marginTop:24 }}>
            <div style={{ fontSize:11, fontWeight:700, color:"#706050", marginBottom:8 }}>📝 {isAr?'ملاحظات:':'Notes:'}</div>
            <textarea value={config.manualNotesText} onChange={e => setConfig(prev => ({ ...prev, manualNotesText:e.target.value }))} placeholder={t.notesPlaceholder} style={{ width:"100%", padding:12, background: isLight?"#fff":"rgba(255,255,255,0.03)", border:"1px dashed rgba(200,151,58,0.3)", borderRadius:8, color: isLight?"#000":"#F5EDD6", fontSize:12, fontFamily:"inherit", minHeight:80, outline:"none" }}/>
          </div>
        )}
      </div>

      {showConfig && <ReportConfigPanel config={config} setConfig={setConfig} onClose={() => setShowConfig(false)} t={t}/>}
    </div>
  );
}
