/* ═══════════════════════════════════════════
   app.js — Root App Component
   ═══════════════════════════════════════════ */

function App() {
  /* ── Language ── */
  const [lang, setLang] = useState(() => load("ls_lang", "ar"));
  const t    = T[lang];
  const isAr = lang === "ar";
  const getBN = b => b.nameEn;

  const toggleLang = useCallback(() => {
    const newLang = lang === "ar" ? "en" : "ar";
    setLang(newLang);
    localStorage.setItem("ls_lang", JSON.stringify(newLang));
    document.documentElement.lang = newLang;
    document.documentElement.dir  = T[newLang].dir;
  }, [lang]);

  useEffect(() => {
    document.documentElement.lang = lang;
    document.documentElement.dir  = t.dir;
  }, [lang, t.dir]);

  /* ── Auth ── */
  const [pinState] = useState(() => {
    if (hasPIN()) return 'check';
    if (localStorage.getItem('ls_pin_skipped')) return 'skip';
    return 'set';
  });
  const [unlocked, setUnlocked] = useState(
    () => !!localStorage.getItem('ls_pin_skipped') && !hasPIN()
  );

  /* ── Persistent state ── */
  const [branches,  setBranches]  = useState(() => load("ls_branches", INIT_BRANCHES));
  const [data,      setData]      = useState(() => load("ls_data", {}));
  const [restName,  setRestName]  = useState(() => load("ls_name", "La Shawermeria"));

  useEffect(() => localStorage.setItem("ls_branches", JSON.stringify(branches)), [branches]);
  useEffect(() => localStorage.setItem("ls_data",     JSON.stringify(data)),     [data]);
  useEffect(() => localStorage.setItem("ls_name",     JSON.stringify(restName)), [restName]);

  /* ── UI state ── */
  const [activeBranch,  setActiveBranch]  = useState(null);
  const [activeSection, setActiveSection] = useState(null);
  const [dateFilter,    setDateFilter]    = useState("today");
  const [selDate,       setSelDate]       = useState(now());
  const [currentTime,   setCurrentTime]   = useState(Date.now());
  const [lastUpdated,   setLastUpdated]   = useState(null);
  const [flashMsg,      setFlashMsg]      = useState(null);

  /* ── Modal flags ── */
  const [showAdd,         setShowAdd]         = useState(false);
  const [showDel,         setShowDel]         = useState(null);
  const [editingBranch,   setEditingBranch]   = useState(null);
  const [nameEn,          setNameEn]          = useState("");
  const [showCal,         setShowCal]         = useState(false);
  const [editItem,        setEditItem]        = useState(null);
  const [showOnline,      setShowOnline]      = useState(false);
  const [showGlovo,       setShowGlovo]       = useState(false);
  const [showUberEats,    setShowUberEats]    = useState(false);
  const [showReport,      setShowReport]      = useState(false);
  const [showSettings,    setShowSettings]    = useState(false);
  const [showBackupReminder, setShowBackupReminder] = useState(false);

  /* ── Clock tick (for "today" live updates) ── */
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(Date.now()), 60000);
    return () => clearInterval(timer);
  }, []);

  /* ── Weekly backup reminder ── */
  useEffect(() => {
    const today = new Date();
    if (today.getDay() !== 1) return;
    const todayKey    = dKey(today.getFullYear(), today.getMonth()+1, today.getDate());
    const lastReminder = localStorage.getItem("ls_backup_reminder");
    if (lastReminder === todayKey) return;
    const lastExport  = localStorage.getItem("ls_last_export");
    if (!lastExport) { setShowBackupReminder(true); return; }
    if ((Date.now() - parseInt(lastExport)) / 86400000 >= 7) setShowBackupReminder(true);
  }, []);

  /* ── Flash helper ── */
  const triggerFlash = (msg) => {
    setFlashMsg(msg);
    setTimeout(() => setFlashMsg(null), 1700);
  };

  /* ── Date range ── */
  const dateRange = useMemo(() => {
    const n = new Date(currentTime);
    if (dateFilter==="today") return [dKey(n.getFullYear(), n.getMonth()+1, n.getDate())];
    if (dateFilter==="week")  return Array.from({length:7}, (_, i) => { const d=new Date(n); d.setDate(n.getDate()-6+i); return dKey(d.getFullYear(),d.getMonth()+1,d.getDate()); });
    if (dateFilter==="month") { const y=n.getFullYear(),m=n.getMonth()+1,dim=new Date(y,m,0).getDate(); return Array.from({length:dim},(_,i)=>dKey(y,m,i+1)); }
    return [dKey(selDate.year, selDate.month, selDate.day)];
  }, [dateFilter, selDate, currentTime]);

  /* ── Aggregated totals ── */
  const agg = useMemo(() => {
    const bids = activeBranch ? [activeBranch] : branches.map(b => b.id);
    const sum  = (sec, sub) => bids.reduce((acc,bid) => acc + dateRange.reduce((a,k) => a+((data[bid]?.[k]?.[sec]?.[sub])||0),0),0);
    return {
      direct:      sum("sales","direct"),
      glovo:       sum("sales","glovo"),       glovoNet:     sum("sales","glovo_net"),
      uberEats:    sum("sales","uberEats"),    uberEatsNet:  sum("sales","uberEats_net"),
      uberEatsAd:  sum("sales","uberEats_ad"), lastApp:      sum("sales","lastApp"),
      meat:        sum("purchases","meat"),    mercadona:    sum("purchases","mercadona"),
      macro:       sum("purchases","macro"),   veg:          sum("purchases","veg"),
      baklawa:     sum("purchases","baklawa"), bread:        sum("purchases","bread"),
      rent:        sum("expenses","rent"),     electricity:  sum("expenses","electricity"),
      salaries:    sum("expenses","salaries"), water:        sum("expenses","water"),
      other:       sum("expenses","other")
    };
  }, [data, activeBranch, branches, dateRange]);

  const totalSales     = agg.direct + agg.glovoNet + agg.uberEatsNet + agg.lastApp;
  const totalPurchases = agg.meat + agg.mercadona + agg.macro + agg.veg + agg.baklawa + agg.bread;
  const totalExpenses  = agg.rent + agg.electricity + agg.salaries + agg.water + agg.other;
  const netProfit      = totalSales - totalPurchases - totalExpenses;
  const warn           = (totalPurchases + totalExpenses) > totalSales && totalSales > 0;
  const purchaseRatio  = totalSales > 0 ? (totalPurchases / totalSales) * 100 : 0;
  const canEdit        = dateFilter === "today" || dateFilter === "custom";

  /* ── Save helpers ── */
  const saveValue = (amount, note, branchId) => {
    if (!editItem) return;
    const { section, sub } = editItem;
    const dk = getActiveKey(dateFilter, selDate);
    setData(prev => ({
      ...prev,
      [branchId]: {
        ...(prev[branchId]||{}),
        [dk]: {
          ...((prev[branchId]||{})[dk]||{}),
          [section]: { ...(((prev[branchId]||{})[dk]||{})[section]||{}), [sub]: amount, [sub+"_note"]: note }
        }
      }
    }));
    setEditItem(null); setLastUpdated(Date.now()); triggerFlash(t.savedFlash);
  };

  const saveGlovoValue = (gross, net, note, branchId) => {
    const dk = getActiveKey(dateFilter, selDate);
    setData(prev => ({
      ...prev,
      [branchId]: {
        ...(prev[branchId]||{}),
        [dk]: {
          ...((prev[branchId]||{})[dk]||{}),
          sales: { ...(((prev[branchId]||{})[dk]||{}).sales||{}), glovo: gross, glovo_net: net, glovo_note: note }
        }
      }
    }));
    setShowGlovo(false); setLastUpdated(Date.now()); triggerFlash(t.savedFlash);
  };

  const saveUberEatsValue = (gross, net, ad, note, branchId) => {
    const dk = getActiveKey(dateFilter, selDate);
    setData(prev => ({
      ...prev,
      [branchId]: {
        ...(prev[branchId]||{}),
        [dk]: {
          ...((prev[branchId]||{})[dk]||{}),
          sales: { ...(((prev[branchId]||{})[dk]||{}).sales||{}), uberEats: gross, uberEats_net: net, uberEats_ad: ad, uberEats_note: note }
        }
      }
    }));
    setShowUberEats(false); setLastUpdated(Date.now()); triggerFlash(t.savedFlash);
  };

  const getNote = (sec, sub) => {
    const dk = getActiveKey(dateFilter, selDate);
    if (activeBranch) return data[activeBranch]?.[dk]?.[sec]?.[sub+"_note"] || "";
    const notes = branches.map(b => data[b.id]?.[dk]?.[sec]?.[sub+"_note"]).filter(n=>n);
    return notes.length > 0 ? notes.join(" | ") : "";
  };

  /* ── Branch CRUD ── */
  const addBranch = () => {
    if (!nameEn.trim()) return;
    setBranches(p => [...p, { id:Date.now(), nameEn:nameEn.trim(), color:COLORS[p.length%COLORS.length], icon:"🏪" }]);
    setNameEn(""); setShowAdd(false);
  };
  const saveBranchEdit = () => {
    setBranches(p => p.map(b => b.id===editingBranch.id ? { ...b, nameEn: nameEn||b.nameEn } : b));
    setEditingBranch(null); setNameEn("");
  };
  const delBranch = id => {
    setBranches(p => p.filter(b => b.id!==id));
    if (activeBranch===id) setActiveBranch(null);
    setShowDel(null);
  };

  /* ── Backup / Restore ── */
  const exportBackup = () => {
    const backup = {
      branches: JSON.parse(localStorage.getItem("ls_branches")||"[]"),
      data:     JSON.parse(localStorage.getItem("ls_data")||"{}"),
      restName: JSON.parse(localStorage.getItem("ls_name")||'"La Shawermeria"'),
      exportDate: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backup,null,2)],{type:"application/json"});
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement("a");
    a.href = url; a.download = `LaShawermeria_Backup_${new Date().toISOString().split("T")[0]}.json`;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    localStorage.setItem("ls_last_export", Date.now().toString());
    localStorage.setItem("ls_backup_reminder", dKey(new Date().getFullYear(), new Date().getMonth()+1, new Date().getDate()));
    setShowBackupReminder(false); triggerFlash("✓ " + t.exportBtn);
  };

  const importBackup = (file) => {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const backup = JSON.parse(e.target.result);
        if (!backup.branches || !backup.data || !backup.restName) throw new Error("Invalid format");
        if (window.confirm(t.importConfirm)) {
          localStorage.setItem("ls_branches", JSON.stringify(backup.branches));
          localStorage.setItem("ls_data",     JSON.stringify(backup.data));
          localStorage.setItem("ls_name",     JSON.stringify(backup.restName));
          alert(t.importSuccess);
          window.location.reload();
        }
      } catch (err) { alert(t.importError); console.error("Import error:", err); }
    };
    reader.readAsText(file);
  };

  /* ── Derived display values ── */
  const selectedLabel = activeBranch ? getBN(branches.find(b=>b.id===activeBranch)||{}) : t.allBranches;
  const branchToDel   = branches.find(b => b.id===showDel);
  const dateDisplay   = dateFilter==="custom" ? `${String(selDate.day).padStart(2,"0")} / ${String(selDate.month).padStart(2,"0")} / ${selDate.year}` : dateFilter==="today" ? t.filterToday : dateFilter==="week" ? t.filterWeek : t.filterMonth;

  /* ── PIN gate ── */
  if (!unlocked) return (
    <PinScreen mode={pinState} t={t} onSuccess={() => setUnlocked(true)} onSkip={() => { localStorage.setItem('ls_pin_skipped','1'); setUnlocked(true); }}/>
  );

  /* ════════════════════════════════════════════
     RENDER
  ════════════════════════════════════════════ */
  return (
    <div style={{ minHeight:"100vh", background:"#0F0E0A", fontFamily:"'Cairo',sans-serif", direction:t.dir, color:"#F5EDD6", position:"relative" }}>
      {/* Radial bg */}
      <div style={{ position:"fixed", inset:0, zIndex:0, pointerEvents:"none", background:"radial-gradient(ellipse at 20% 20%,#1A1508 0%,#0F0E0A 60%)" }}/>
      {/* Gold top bar */}
      <div style={{ position:"fixed", top:0, left:0, right:0, height:3, zIndex:100, background:"linear-gradient(90deg,transparent,#C8973A,#F0C060,#C8973A,transparent)" }}/>
      {/* Flash */}
      {flashMsg && <div className="flash-save">{flashMsg}</div>}
      {/* Backup reminder banner */}
      {showBackupReminder && (
        <div style={{ position:"fixed",top:0,left:0,right:0,zIndex:300,background:"rgba(200,120,0,0.97)",padding:"10px 14px",display:"flex",alignItems:"center",justifyContent:"space-between",gap:8,fontFamily:"'Cairo',sans-serif" }}>
          <span style={{ fontSize:11,fontWeight:700,color:"#fff",flex:1 }}>{t.backupReminder}</span>
          <button onClick={exportBackup} style={{ ...btn("rgba(255,255,255,0.2)","none","#fff",{padding:"5px 10px",fontSize:10,border:"none",flexShrink:0}) }}>{t.backupReminderBtn}</button>
          <button onClick={() => { localStorage.setItem("ls_backup_reminder",getTodayKey()); setShowBackupReminder(false); }} style={{ background:"transparent",border:"none",color:"rgba(255,255,255,0.7)",fontSize:16,cursor:"pointer",padding:"0 4px",flexShrink:0 }}>✕</button>
        </div>
      )}
      {/* Top-right action buttons */}
      <div style={{ position:"fixed", top:9, [isAr?"left":"right"]:12, zIndex:100, display:"flex", gap:6 }}>
        {[
          { icon:"📊", action:()=>setShowReport(true),   col:"#3AC87D", border:"rgba(58,200,125,0.35)" },
          { icon:"⚙️", action:()=>setShowSettings(true), col:"#C8973A", border:"rgba(200,151,58,0.4)"  },
          { icon: isAr?"EN":"عربي", action:toggleLang,   col:"#F0C060", border:"rgba(200,151,58,0.4)"  }
        ].map((b,i) => (
          <button key={i} onClick={b.action} style={{ padding:"5px 10px", background:"rgba(0,0,0,0.3)", border:`1px solid ${b.border}`, borderRadius:20, color:b.col, fontSize:11, fontWeight:700, fontFamily:"inherit", cursor:"pointer" }}>{b.icon}</button>
        ))}
      </div>

      <div style={{ position:"relative", zIndex:1, maxWidth:480, margin:"0 auto", paddingBottom:80 }}>

        {/* ── App Header ── */}
        <div style={{ padding:"44px 20px 16px", textAlign:"center", borderBottom:"1px solid rgba(200,151,58,0.1)" }}>
          <div style={{ fontSize:9, letterSpacing:4, color:"#C8973A", marginBottom:6, textTransform:"uppercase" }}>{t.systemLabel}</div>
          <h1 style={{ fontSize:30, fontWeight:800, margin:0, fontFamily:"'Playfair Display','Cairo',serif", letterSpacing:1, background:"linear-gradient(135deg,#F0C060,#C8973A,#A67828)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>{restName}</h1>
          <div style={{ width:44, height:2, background:"linear-gradient(90deg,transparent,#C8973A,transparent)", margin:"10px auto 0" }}/>
        </div>

        {/* ── Branch tabs ── */}
        <div style={{ padding:"14px 10px 4px" }}>
          <div style={{ display:"flex", alignItems:"center", gap:6, overflowX:"auto", paddingBottom:4, scrollbarWidth:"none" }}>
            <button onClick={() => setActiveBranch(null)} style={{ flexShrink:0, padding:"7px 13px", borderRadius:50, fontFamily:"inherit", border: activeBranch===null?"1.5px solid #C8973A":"1px solid rgba(200,151,58,0.2)", background: activeBranch===null?"rgba(200,151,58,0.12)":"rgba(255,255,255,0.03)", color: activeBranch===null?"#F0C060":"#807060", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", display:"flex", alignItems:"center", gap:4 }}>🏢 {t.allBranches}</button>
            {branches.map(b => (
              <button key={b.id} onClick={() => setActiveBranch(b.id)} style={{ flexShrink:0, padding:"7px 13px", borderRadius:50, fontFamily:"inherit", border: activeBranch===b.id?`1.5px solid ${b.color}`:"1px solid rgba(255,255,255,0.07)", background: activeBranch===b.id?`${b.color}22`:"rgba(255,255,255,0.03)", color: activeBranch===b.id?b.color:"#706050", fontSize:11, fontWeight:700, cursor:"pointer", whiteSpace:"nowrap", display:"flex", alignItems:"center", gap:4 }}>{b.icon} {getBN(b)}</button>
            ))}
            <button onClick={() => setShowAdd(true)} style={{ flexShrink:0, width:32, height:32, borderRadius:"50%", border:"1.5px dashed rgba(200,151,58,0.35)", background:"transparent", color:"#C8973A", fontSize:17, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"inherit" }}>+</button>
          </div>
        </div>

        {/* ── Active branch info card ── */}
        <div style={{ padding:"7px 10px 0" }}>
          <div style={{ background:"linear-gradient(135deg,rgba(200,151,58,0.1),rgba(200,151,58,0.03))", border:"1px solid rgba(200,151,58,0.18)", borderRadius:10, padding:"10px 13px", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
            <div style={{ display:"flex", alignItems:"center", gap:8 }}>
              <div style={{ width:30, height:30, background:"rgba(200,151,58,0.13)", borderRadius:7, display:"flex", alignItems:"center", justifyContent:"center", fontSize:14 }}>
                {activeBranch ? branches.find(b=>b.id===activeBranch)?.icon||"🏪" : "🏢"}
              </div>
              <div>
                <div style={{ fontSize:7, color:"#806020", letterSpacing:2, textTransform:"uppercase", marginBottom:1 }}>{t.viewingData}</div>
                <div style={{ fontSize:13, fontWeight:800, color:"#F0C060" }}>{selectedLabel}</div>
                {lastUpdated && (
                  <div style={{ fontSize:8, color:"#504030", marginTop:2 }}>
                    🕐 {isAr?"آخر تحديث: ":"Last update: "}
                    {new Date(lastUpdated).toLocaleString(isAr?"ar-SA":"en-GB",{day:"2-digit",month:"2-digit",year:"numeric",hour:"2-digit",minute:"2-digit"})}
                  </div>
                )}
              </div>
            </div>
            {activeBranch && (
              <button onClick={() => { const b=branches.find(x=>x.id===activeBranch); setEditingBranch(b); setNameEn(b.nameEn); }} style={{ width:28, height:28, borderRadius:7, border:"1px solid rgba(200,151,58,0.25)", background:"rgba(200,151,58,0.07)", color:"#C8973A", fontSize:12, cursor:"pointer", fontFamily:"inherit" }}>✎</button>
            )}
          </div>
        </div>

        {/* ── Date filter ── */}
        <div style={{ padding:"7px 10px 0" }}>
          <div style={{ display:"flex", gap:5 }}>
            {[{key:"today",label:t.filterToday,icon:"☀️"},{key:"week",label:t.filterWeek,icon:"📆"},{key:"month",label:t.filterMonth,icon:"🗓"},{key:"custom",label:t.filterCustom,icon:"✏️"}].map(f => (
              <button key={f.key} onClick={() => { setDateFilter(f.key); if(f.key==="custom") setShowCal(true); }} style={{ flex:1, padding:"6px 2px", borderRadius:9, fontFamily:"inherit", border: dateFilter===f.key?"1.5px solid #C8973A":"1px solid rgba(255,255,255,0.07)", background: dateFilter===f.key?"rgba(200,151,58,0.13)":"rgba(255,255,255,0.03)", color: dateFilter===f.key?"#F0C060":"#605050", fontSize:9, fontWeight: dateFilter===f.key?800:500, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:2 }}>
                <span style={{ fontSize:13 }}>{f.icon}</span> <span>{f.label}</span>
              </button>
            ))}
          </div>
          {dateFilter==="custom" && (
            <button onClick={() => setShowCal(true)} style={{ marginTop:6, width:"100%", padding:"6px 12px", background:"rgba(200,151,58,0.07)", border:"1px solid rgba(200,151,58,0.2)", borderRadius:8, color:"#F0C060", fontFamily:"inherit", cursor:"pointer", fontSize:11, fontWeight:700, display:"flex", alignItems:"center", justifyContent:"space-between" }}>
              <span>📅 {dateDisplay}</span> <span style={{ color:"#705020", fontSize:9 }}>▼</span>
            </button>
          )}
          {!canEdit && activeSection && (
            <div style={{ marginTop:6, padding:"6px 10px", background:"rgba(200,151,58,0.08)", border:"1px solid rgba(200,151,58,0.2)", borderRadius:8, fontSize:10, color:"#C8973A", textAlign:"center" }}>
              ⚠️ {t.editModeWarning}
            </div>
          )}
        </div>

        {/* ── Summary strip ── */}
        <div style={{ margin:"10px 10px 0", borderRadius:11, padding:"10px 12px", border:`1px solid ${warn?"rgba(200,60,60,0.35)":"rgba(255,255,255,0.07)"}` }}>
          {warn && <div style={{ fontSize:10, color:"#C84040", textAlign:"center", marginBottom:7, fontWeight:700 }}>{t.warningMsg}</div>}
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr 1.2fr", gap:5 }}>
            {[
              { label:t.salesBtn+" (Net)", val:totalSales,     col:"#C8973A" },
              { label:t.purchasesBtn,      val:totalPurchases,  col:"#3A7DC8", subLabel:`${purchaseRatio.toFixed(1)}% ${t.ratioLabel}`, subColor: getRatioColor(purchaseRatio), status: getRatioStatus(purchaseRatio,t) },
              { label:t.expensesBtn,       val:totalExpenses,   col:"#C83A3A" },
              { label:t.profit,            val:netProfit,       col:netProfit>=0?"#3AC87D":"#C83A3A" }
            ].map((s,i) => (
              <div key={i} style={{ textAlign:"center" }}>
                <div style={{ fontSize:7, color:"#504030", marginBottom:2 }}>{s.label}</div>
                <div style={{ fontSize:10, fontWeight:800, color:s.col }} className="western-numerals">{fmt(s.val)}</div>
                {s.subLabel && (
                  <div style={{ fontSize:8, fontWeight:700, color:s.subColor, marginTop:4, background:`${s.subColor}15`, padding:"2px 4px", borderRadius:4, display:"inline-block" }} className="western-numerals">{s.subLabel} ({s.status})</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ── 7-day chart ── */}
        <Chart data={data} branches={branches} activeBranch={activeBranch} t={t}/>

        {/* ── Section buttons ── */}
        <div style={{ padding:"10px 10px 0", display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
          {[{key:"sales",label:t.salesBtn,icon:"💰",color:"#C8973A"},{key:"purchases",label:t.purchasesBtn,icon:"🛒",color:"#3A7DC8"},{key:"expenses",label:t.expensesBtn,icon:"📤",color:"#C83A3A"}].map(s => (
            <button key={s.key} onClick={() => setActiveSection(activeSection===s.key ? null : s.key)} style={{ padding:"13px 6px", borderRadius:12, fontFamily:"inherit", background: activeSection===s.key?`linear-gradient(135deg,${s.color},${s.color}99)`:`${s.color}0D`, border: activeSection===s.key?"none":`1px solid ${s.color}38`, color: activeSection===s.key?"#0F0E0A":s.color, cursor:"pointer", display:"flex", flexDirection:"column", alignItems:"center", gap:5 }}>
              <span style={{ fontSize:21 }}>{s.icon}</span>
              <span style={{ fontSize:11, fontWeight:800 }}>{s.label}</span>
            </button>
          ))}
        </div>

        {/* ── Sales section ── */}
        {activeSection==="sales" && (
          <div style={{ padding:"9px 10px 0" }}>
            <DataRow icon="🏪" color="#C8973A" label={t.directSales} desc={t.directSalesDesc} value={agg.direct} note={getNote("sales","direct")} isAr={isAr} onPress={canEdit ? () => setEditItem({section:"sales",sub:"direct",label:t.directSales,icon:"🏪",color:"#C8973A"}) : null}/>
            {/* Online sales row */}
            <div onClick={canEdit ? () => setShowOnline(true) : null} style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:12, padding:"11px 13px", marginBottom:7, display:"flex", alignItems:"center", justifyContent:"space-between", cursor:canEdit?"pointer":"default", borderRight: isAr?"3px solid #8B3AC8":undefined, borderLeft: !isAr?"3px solid #8B3AC8":undefined }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:34, height:34, background:"#8B3AC818", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16 }}>📱</div>
                <div>
                  <div style={{ fontSize:12, fontWeight:700, color:"#F5EDD6" }}>{t.onlineSales}</div>
                  <div style={{ fontSize:9, color:"#504030", marginTop:1 }}>{[t.glovo,t.uberEats,t.lastApp].join(" · ")}</div>
                </div>
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <span style={{ fontSize:13, fontWeight:800, color:"#8B3AC8" }} className="western-numerals">{fmt(agg.glovoNet+agg.uberEatsNet+agg.lastApp)}</span>
                {canEdit && <span style={{ fontSize:11, color:"#403030" }}>›</span>}
              </div>
            </div>
            <DataRow icon="📊" color="#3AC87D" label={t.totalSales} value={totalSales} isTotal isAr={isAr}/>
          </div>
        )}

        {/* ── Purchases section ── */}
        {activeSection==="purchases" && (
          <div style={{ padding:"9px 10px 0" }}>
            {[{sub:"meat",label:t.meat,icon:"🥩",color:"#C83A3A"},{sub:"mercadona",label:t.mercadona,icon:"🏬",color:"#3A7DC8"},{sub:"macro",label:t.macro,icon:"📦",color:"#8B3AC8"},{sub:"veg",label:t.veg,icon:"🥬",color:"#3AC87D"},{sub:"baklawa",label:t.baklawa,icon:"🍯",color:"#C8973A"},{sub:"bread",label:t.bread,icon:"🍞",color:"#C8683A"}].map(item => (
              <DataRow key={item.sub} {...item} value={agg[item.sub]} note={getNote("purchases",item.sub)} isAr={isAr} onPress={canEdit ? () => setEditItem({section:"purchases",sub:item.sub,...item}) : null}/>
            ))}
            <DataRow icon="📊" color="#3A7DC8" label={t.total} value={totalPurchases} isTotal isAr={isAr}/>
          </div>
        )}

        {/* ── Expenses section ── */}
        {activeSection==="expenses" && (
          <div style={{ padding:"9px 10px 0" }}>
            {[{sub:"rent",label:t.rent,icon:"🏠",color:"#C83A3A"},{sub:"electricity",label:t.electricity,icon:"⚡",color:"#C8C03A"},{sub:"salaries",label:t.salaries,icon:"👥",color:"#3AC87D"},{sub:"water",label:t.water,icon:"💧",color:"#3A7DC8"},{sub:"other",label:t.other,icon:"📋",color:"#8B3AC8"}].map(item => (
              <DataRow key={item.sub} {...item} value={agg[item.sub]} note={getNote("expenses",item.sub)} isAr={isAr} onPress={canEdit ? () => setEditItem({section:"expenses",sub:item.sub,...item}) : null}/>
            ))}
            <DataRow icon="📊" color="#C83A3A" label={t.total} value={totalExpenses} isTotal isAr={isAr}/>
          </div>
        )}

        {/* ── Branch list (all-branches view) ── */}
        {activeBranch===null && (
          <div style={{ padding:"12px 10px 0" }}>
            <div style={{ fontSize:9, color:"#504030", marginBottom:8, padding:"0 2px" }}>{t.branches} ({branches.length})</div>
            {branches.map(b => (
              <div key={b.id} style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:12, padding:"12px 13px", marginBottom:7, display:"flex", alignItems:"center", justifyContent:"space-between", borderRight: isAr?`3px solid ${b.color}`:undefined, borderLeft: !isAr?`3px solid ${b.color}`:undefined }}>
                <div onClick={() => setActiveBranch(b.id)} style={{ display:"flex", alignItems:"center", gap:10, cursor:"pointer", flex:1 }}>
                  <div style={{ width:38, height:38, background:`${b.color}1C`, borderRadius:9, display:"flex", alignItems:"center", justifyContent:"center", fontSize:17 }}>{b.icon}</div>
                  <div>
                    <div style={{ fontWeight:700, fontSize:13, color:"#F5EDD6" }}>{getBN(b)}</div>
                    <div style={{ fontSize:9, color:"#504030", marginTop:1 }}>{t.enterBranch}</div>
                  </div>
                </div>
                <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                  <button onClick={() => { setEditingBranch(b); setNameEn(b.nameEn); }} style={{ width:27, height:27, borderRadius:7, border:"1px solid rgba(200,151,58,0.28)", background:"rgba(200,151,58,0.06)", color:"#C8973A", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>✎</button>
                  <button onClick={() => setShowDel(b.id)} style={{ width:27, height:27, borderRadius:7, border:"1px solid rgba(200,60,60,0.28)", background:"rgba(200,60,60,0.06)", color:"#C84040", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>🗑</button>
                  <span onClick={() => setActiveBranch(b.id)} style={{ color:"#C8973A", fontSize:14, cursor:"pointer" }}>{isAr?"←":"→"}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ════ MODALS ════ */}

      {/* Add branch */}
      {showAdd && (
        <Sheet onClose={() => setShowAdd(false)}>
          <h2 style={{ margin:"0 0 16px", fontSize:16, fontWeight:800, color:"#F0C060" }}>{t.addBranch}</h2>
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:9, color:"#806030", marginBottom:4 }}>{t.nameEn}</div>
            <input autoFocus value={nameEn} onChange={e => setNameEn(e.target.value.replace(/[^A-Za-z0-9\s\-]/g,''))} onKeyDown={e => e.key==="Enter" && addBranch()} placeholder="e.g. Dammam Branch" style={{ ...inputStyle("ltr") }}/>
            <div style={{ fontSize:8, color:"#605040", marginTop:4 }}>{t.nameEnHint}</div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={addBranch}          style={{ ...btn("linear-gradient(135deg,#C8973A,#A67828)","none","#0F0E0A",{flex:1,border:"none"}) }}>{t.addBtn}</button>
            <button onClick={() => setShowAdd(false)} style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 14px"}) }}>{t.cancel}</button>
          </div>
        </Sheet>
      )}

      {/* Edit branch */}
      {editingBranch && (
        <Sheet onClose={() => setEditingBranch(null)}>
          <h2 style={{ margin:"0 0 16px", fontSize:16, fontWeight:800, color:"#F0C060" }}>{t.editBranch}</h2>
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:9, color:"#806030", marginBottom:4 }}>{t.nameEn}</div>
            <input autoFocus value={nameEn} onChange={e => setNameEn(e.target.value.replace(/[^A-Za-z0-9\s\-]/g,''))} onKeyDown={e => e.key==="Enter" && saveBranchEdit()} style={{ ...inputStyle("ltr") }}/>
            <div style={{ fontSize:8, color:"#605040", marginTop:4 }}>{t.nameEnHint}</div>
          </div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={saveBranchEdit}           style={{ ...btn("linear-gradient(135deg,#C8973A,#A67828)","none","#0F0E0A",{flex:1,border:"none"}) }}>{t.saveBtn}</button>
            <button onClick={() => setEditingBranch(null)} style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 14px"}) }}>{t.cancel}</button>
          </div>
        </Sheet>
      )}

      {/* Delete confirm */}
      {showDel && branchToDel && (
        <div onClick={e => e.target===e.currentTarget && setShowDel(null)} style={{ position:"fixed", inset:0, zIndex:200, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"center", justifyContent:"center", backdropFilter:"blur(5px)", padding:"0 18px" }} className="backdrop-blur">
          <div style={{ background:"#1A1208", border:"1px solid rgba(200,60,60,0.28)", borderTop:"2px solid #C84040", borderRadius:15, padding:"22px 18px", width:"100%", maxWidth:320, textAlign:"center" }}>
            <div style={{ fontSize:32, marginBottom:10 }}>🗑️</div>
            <h2 style={{ margin:"0 0 7px", fontSize:15, fontWeight:800, color:"#FF7060" }}>{t.deleteBranch}</h2>
            <p style={{ margin:"0 0 5px", color:"#F5EDD6", fontSize:13 }}>{t.deleteConfirm} <strong style={{ color:"#F0C060" }}>"{getBN(branchToDel)}"</strong>؟</p>
            <p style={{ margin:"0 0 20px", color:"#504030", fontSize:10 }}>{t.deleteWarning}</p>
            <div style={{ display:"flex", gap:8 }}>
              <button onClick={() => delBranch(showDel)} style={{ ...btn("linear-gradient(135deg,#C84040,#A02020)","none","#fff",{flex:1,border:"none"}) }}>{t.deleteBtn}</button>
              <button onClick={() => setShowDel(null)}   style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 14px"}) }}>{t.cancel}</button>
            </div>
          </div>
        </div>
      )}

      {/* Online sales picker */}
      {showOnline && (
        <Sheet onClose={() => setShowOnline(false)} borderColor="#8B3AC8">
          <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:16 }}>
            <span style={{ fontSize:20 }}>📱</span>
            <span style={{ fontSize:15, fontWeight:800, color:"#C090F0" }}>{t.onlineSales}</span>
          </div>
          {[{sub:"glovo",label:t.glovo,icon:"🟡",color:"#FF6B00"},{sub:"uberEats",label:t.uberEats,icon:"🚗",color:"#06C167"},{sub:"lastApp",label:t.lastApp,icon:"🔵",color:"#0084FF"}].map(item => (
            <div key={item.sub} onClick={() => {
              if (item.sub==="glovo")    { setShowOnline(false); setShowGlovo(true); }
              else if (item.sub==="uberEats") { setShowOnline(false); setShowUberEats(true); }
              else { setShowOnline(false); setEditItem({section:"sales",sub:item.sub,...item}); }
            }} style={{ background:"rgba(255,255,255,0.03)", border:`1px solid ${item.color}28`, borderRadius:11, padding:"11px 13px", marginBottom:8, display:"flex", alignItems:"center", justifyContent:"space-between", cursor:"pointer", borderRight: isAr?`3px solid ${item.color}`:undefined, borderLeft: !isAr?`3px solid ${item.color}`:undefined }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <div style={{ width:34, height:34, background:`${item.color}16`, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:17 }}>{item.icon}</div>
                <div>
                  <div style={{ fontSize:12, fontWeight:700, color:"#F5EDD6" }}>{item.label}</div>
                  {getNote("sales",item.sub) && <div style={{ fontSize:9, color:"#806040", marginTop:1 }}>📝 {getNote("sales",item.sub)}</div>}
                </div>
              </div>
              <div style={{ display:"flex", alignItems:"center", gap:6 }}>
                <span style={{ fontSize:13, fontWeight:800, color:item.color }} className="western-numerals">
                  {fmt(item.sub==="glovo" ? (agg.glovoNet||0) : item.sub==="uberEats" ? (agg.uberEatsNet||0) : (agg[item.sub]||0))}
                </span>
                <span style={{ fontSize:10, color:"#403020" }}>✎</span>
              </div>
            </div>
          ))}
          <div style={{ background:"rgba(139,58,200,0.1)", border:"1px solid rgba(139,58,200,0.22)", borderRadius:11, padding:"10px 13px", display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <div style={{ display:"flex", alignItems:"center", gap:10 }}>
              <div style={{ width:34, height:34, background:"rgba(139,58,200,0.16)", borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:15 }}>📊</div>
              <span style={{ fontSize:12, fontWeight:700, color:"#C090F0" }}>{t.total}</span>
            </div>
            <span style={{ fontSize:13, fontWeight:800, color:"#C090F0" }} className="western-numerals">{fmt(agg.glovoNet+agg.uberEatsNet+agg.lastApp)}</span>
          </div>
        </Sheet>
      )}

      {/* Amount / Glovo / UberEats modals */}
      {editItem && !showGlovo && !showUberEats && (
        <AmountModal label={editItem.label} icon={editItem.icon} color={editItem.color} current={agg[editItem.sub]||0} currentNote={getNote(editItem.section, editItem.sub)} branches={branches} activeBranch={activeBranch} getBN={getBN} onSave={saveValue} onClose={() => setEditItem(null)} t={t}/>
      )}
      {showGlovo    && <GlovoModal    data={data} currentDateKey={getActiveKey(dateFilter,selDate)} branches={branches} activeBranch={activeBranch} onSave={saveGlovoValue}    onClose={() => setShowGlovo(false)}    t={t} isAr={isAr}/>}
      {showUberEats && <UberEatsModal data={data} currentDateKey={getActiveKey(dateFilter,selDate)} branches={branches} activeBranch={activeBranch} onSave={saveUberEatsValue} onClose={() => setShowUberEats(false)} t={t} isAr={isAr}/>}

      {/* Calendar */}
      {showCal && <CalModal t={t} isAr={isAr} sel={selDate} onSelect={d => { setSelDate(d); setShowCal(false); setDateFilter("custom"); }} onClose={() => setShowCal(false)}/>}

      {/* Report & Settings screens */}
      {showReport   && <AdvancedReport data={data} branches={branches} t={t} isAr={isAr} onClose={() => setShowReport(false)}   restName={restName}/>}
      {showSettings && <SettingsScreen restName={restName} setRestName={setRestName} triggerFlash={triggerFlash} onClose={() => setShowSettings(false)} t={t} onExport={exportBackup} onImport={importBackup}/>}
    </div>
  );
}

/* ── Mount ── */
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
