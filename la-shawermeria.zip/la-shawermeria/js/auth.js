/* ═══════════════════════════════════════════
   auth.js — PIN Authentication
   ═══════════════════════════════════════════ */

async function hashPIN(pin) {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + "ls_salt_2024");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, "0")).join("");
}

async function savePIN(pin) {
  const hashed = await hashPIN(pin);
  localStorage.setItem("ls_pin_hash", hashed);
  localStorage.removeItem("ls_pin");
}

async function checkPIN(pin) {
  const storedHash = localStorage.getItem("ls_pin_hash");
  if (storedHash) {
    const hashed = await hashPIN(pin);
    return hashed === storedHash;
  }
  /* migrate old plain-text PIN */
  const oldPin = localStorage.getItem("ls_pin");
  if (oldPin && pin === oldPin) {
    await savePIN(pin);
    return true;
  }
  return false;
}

const hasPIN = () =>
  !!(localStorage.getItem("ls_pin_hash") || localStorage.getItem("ls_pin"));
