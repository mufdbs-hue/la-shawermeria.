/* ═══════════════════════════════════════════
   components.js — Shared UI Components
   ═══════════════════════════════════════════ */

/* ── Sheet (Bottom Drawer) ── */
function Sheet({ onClose, borderColor = "#C8973A", children }) {
  return (
    <div
      onClick={e => e.target === e.currentTarget && onClose()}
      style={{ position:"fixed", inset:0, zIndex:200, background:"rgba(0,0,0,0.8)", display:"flex", alignItems:"flex-end", justifyContent:"center", backdropFilter:"blur(5px)" }}
      className="backdrop-blur"
    >
      <div style={{ background:"#1A1810", borderTop:`2px solid ${borderColor}`, borderRadius:"20px 20px 0 0", padding:"22px 20px 44px", width:"100%", maxWidth:480, maxHeight:"90vh", overflowY:"auto" }}>
        <div style={{ width:34, height:4, background:"rgba(255,255,255,0.1)", borderRadius:2, margin:"0 auto 18px" }}/>
        {children}
      </div>
    </div>
  );
}

/* ── Notes Field ── */
function NotesField({ notes, onChange, t, accentColor = "rgba(255,255,255,0.08)" }) {
  const addNote    = () => onChange([...notes, ""]);
  const updateNote = (i, val) => { const n = [...notes]; n[i] = val; onChange(n); };
  const removeNote = (i) => onChange(notes.filter((_, idx) => idx !== i));

  return (
    <div style={{ marginBottom:14 }}>
      {notes.map((n, i) => (
        <div key={i} style={{ display:"flex", gap:6, marginBottom:7, alignItems:"center" }}>
          <input
            value={n}
            onChange={e => updateNote(i, e.target.value)}
            placeholder={`${t.note} ${notes.length > 1 ? i + 1 : ""}`}
            style={{ ...inputStyle("rtl"), fontSize:12, border:`1px solid ${accentColor}`, background:"rgba(255,255,255,0.03)", color:"#C0A870", flex:1 }}
          />
          {notes.length > 1 && (
            <button onClick={() => removeNote(i)} style={{ flexShrink:0, width:28, height:28, borderRadius:8, background:"rgba(200,60,60,0.1)", border:"1px solid rgba(200,60,60,0.25)", color:"#C84040", fontSize:14, cursor:"pointer", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"inherit" }}>✕</button>
          )}
        </div>
      ))}
      <button onClick={addNote} style={{ display:"flex", alignItems:"center", gap:5, background:"rgba(255,255,255,0.03)", border:"1px dashed rgba(255,255,255,0.12)", borderRadius:9, padding:"7px 12px", color:"#606050", fontSize:11, fontWeight:700, cursor:"pointer", fontFamily:"inherit", width:"100%", justifyContent:"center" }}>
        <span style={{ fontSize:16, lineHeight:1 }}>+</span> {t.note}
      </button>
    </div>
  );
}

/* ── Data Row ── */
function DataRow({ icon, color, label, desc, note, value, isTotal, onPress, isAr }) {
  return (
    <div
      onClick={onPress}
      style={{ background: isTotal ? `${color}12` : "rgba(255,255,255,0.03)", border: `1px solid ${isTotal ? color+"30" : "rgba(255,255,255,0.06)"}`, borderRadius:12, padding:"11px 13px", marginBottom:7, display:"flex", alignItems:"center", justifyContent:"space-between", cursor: onPress ? "pointer" : "default", borderRight: isAr && !isTotal ? `3px solid ${color}` : undefined, borderLeft: !isAr && !isTotal ? `3px solid ${color}` : undefined }}
    >
      <div style={{ display:"flex", alignItems:"center", gap:10 }}>
        <div style={{ width:34, height:34, background:`${color}18`, borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:16, flexShrink:0 }}>{icon}</div>
        <div>
          <div style={{ fontSize:12, fontWeight:700, color: isTotal ? color : "#F5EDD6" }}>{label}</div>
          {desc && <div style={{ fontSize:9, color:"#504030", marginTop:1 }}>{desc}</div>}
          {note && <div style={{ fontSize:9, color:"#806040", marginTop:1 }}>📝 {note}</div>}
        </div>
      </div>
      <div style={{ display:"flex", alignItems:"center", gap:6 }}>
        <span style={{ fontSize:13, fontWeight:800, color }} className="western-numerals">{fmt(value)}</span>
        {onPress && !isTotal && <span style={{ fontSize:10, color:"#403020" }}>✎</span>}
      </div>
    </div>
  );
}

/* ── Mini Bar Chart (7 days) ── */
function Chart({ data, branches, activeBranch, t }) {
  const n = new Date();
  const days = Array.from({ length:7 }, (_, i) => {
    const d = new Date(n);
    d.setDate(n.getDate() - 6 + i);
    return { k: dKey(d.getFullYear(), d.getMonth()+1, d.getDate()), label: String(d.getDate()).padStart(2,"0") };
  });
  const bids = activeBranch ? [activeBranch] : branches.map(b => b.id);
  const vals = days.map(({ k }) => bids.reduce((acc, bid) => {
    const s = data[bid]?.[k]?.sales || {};
    return acc + (s.direct||0) + (s.glovo_net||0) + (s.uberEats_net||0) + (s.lastApp||0);
  }, 0));
  const maxV = Math.max(...vals, 1);

  return (
    <div style={{ margin:"10px 12px 0", background:"rgba(255,255,255,0.02)", border:"1px solid rgba(255,255,255,0.06)", borderRadius:12, padding:"12px 12px 8px" }}>
      <div style={{ fontSize:9, color:"#605030", marginBottom:10, fontWeight:700, letterSpacing:1 }}>{t.chart}</div>
      <div style={{ display:"flex", alignItems:"flex-end", gap:5, height:70 }}>
        {vals.map((v, i) => {
          const isT = i === 6;
          const h = Math.max((v / maxV) * 60, v > 0 ? 4 : 2);
          return (
            <div key={i} style={{ flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:3 }}>
              {v > 0 && <div style={{ fontSize:7, color:"#705030" }} className="western-numerals">{v > 999 ? (Math.round(v/100)/10)+"k" : v}</div>}
              <div style={{ width:"100%", height:h, borderRadius:3, transition:"height 0.3s", background: isT ? "#C8973A" : v > 0 ? "rgba(200,151,58,0.35)" : "rgba(255,255,255,0.04)" }}/>
              <div style={{ fontSize:8, color: isT ? "#F0C060" : "#504030" }} className="western-numerals">{days[i].label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
