/* ═══════════════════════════════════════════
   settings.js — Settings Screen
   ═══════════════════════════════════════════ */

function SettingsScreen({ restName, setRestName, triggerFlash, onClose, t, onExport, onImport }) {
  const fileInputRef = React.useRef(null);

  return (
    <div style={{ position:"fixed", inset:0, zIndex:400, background:"#0F0E0A", display:"flex", flexDirection:"column", direction:t.dir, fontFamily:"'Cairo',sans-serif" }}>
      {/* ── Header ── */}
      <div style={{ borderBottom:"1px solid rgba(200,151,58,0.15)", padding:"14px 14px 10px", flexShrink:0 }}>
        <div style={{ height:2, background:"linear-gradient(90deg,transparent,#C8973A,#F0C060,#C8973A,transparent)", marginBottom:12 }}/>
        <div style={{ display:"flex", alignItems:"center", gap:10 }}>
          <button onClick={onClose} style={{ ...btn("rgba(200,151,58,0.08)","rgba(200,151,58,0.3)","#C8973A",{padding:"0",width:34,height:34,fontSize:16}) }}>✕</button>
          <span style={{ fontSize:15, fontWeight:800, color:"#F0C060" }}>{t.settingsTitle}</span>
        </div>
      </div>

      <div style={{ flex:1, overflowY:"auto", padding:"16px 14px 40px" }}>

        {/* ── Backup & Restore ── */}
        <div style={{ background:"rgba(58,200,125,0.05)", border:"1px solid rgba(58,200,125,0.2)", borderRadius:12, padding:"14px", marginBottom:12 }}>
          <div style={{ fontSize:10, color:"#408060", marginBottom:10, fontWeight:700 }}>{t.backupTitle}</div>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={onExport} style={{ ...btn("rgba(58,200,125,0.15)","rgba(58,200,125,0.3)","#3AC87D",{flex:1,fontSize:12}) }}>
              📥 {t.exportBtn}
            </button>
            <button onClick={() => fileInputRef.current.click()} style={{ ...btn("rgba(58,125,200,0.15)","rgba(58,125,200,0.3)","#3A7DC8",{flex:1,fontSize:12}) }}>
              📤 {t.importBtn}
            </button>
          </div>
          <input
            type="file" ref={fileInputRef} accept=".json"
            style={{ display:"none" }}
            onChange={e => { if(e.target.files[0]) { onImport(e.target.files[0]); e.target.value=''; } }}
          />
        </div>

        {/* ── Restaurant Name ── */}
        <div style={{ background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.07)", borderRadius:12, padding:"14px", marginBottom:12 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:8, fontWeight:700 }}>{t.restaurantName}</div>
          <input value={restName} onChange={e => setRestName(e.target.value)} style={{ ...inputStyle("ltr"), fontSize:15, fontWeight:700, marginBottom:10 }}/>
          <button onClick={() => triggerFlash(t.savedFlash)} style={{ ...btn("linear-gradient(135deg,#C8973A,#A67828)","none","#0F0E0A",{width:"100%",border:"none"}) }}>{t.changeNameBtn}</button>
        </div>

        {/* ── Danger Zone ── */}
        <div style={{ background:"rgba(200,60,60,0.05)", border:"1px solid rgba(200,60,60,0.2)", borderRadius:12, padding:"14px" }}>
          <div style={{ fontSize:10, color:"#904030", marginBottom:10, fontWeight:700 }}>{t.clearData}</div>
          <button onClick={() => {
            if (window.confirm(t.clearConfirm)) {
              ['ls_branches','ls_data','ls_name','ls_pin','ls_pin_hash','ls_pin_skipped'].forEach(k => localStorage.removeItem(k));
              window.location.reload();
            }
          }} style={{ ...btn("rgba(200,60,60,0.1)","rgba(200,60,60,0.3)","#C84040",{width:"100%"}) }}>
            🗑 {t.clearData}
          </button>
        </div>

      </div>
    </div>
  );
}
