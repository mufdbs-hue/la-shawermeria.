/* ═══════════════════════════════════════════
   modals.js — All Modal / Sheet Screens
   ═══════════════════════════════════════════ */

/* ── PIN Screen ── */
function PinScreen({ mode, onSuccess, onSkip, t }) {
  const [pin, setPin]           = useState("");
  const [conf, setConf]         = useState("");
  const [step, setStep]         = useState(1);
  const [err, setErr]           = useState("");
  const [checking, setChecking] = useState(false);

  const tap = async (d) => {
    if (checking) return;
    if (mode === "check") {
      const nx = pin + d;
      setPin(nx);
      if (nx.length === 4) {
        setChecking(true);
        const ok = await checkPIN(nx);
        if (ok) { onSuccess(); }
        else {
          setErr(t.pinWrong);
          setTimeout(() => { setPin(""); setErr(""); setChecking(false); }, 800);
        }
      }
    } else {
      if (step === 1) {
        const nx = pin + d;
        setPin(nx);
        if (nx.length === 4) setStep(2);
      } else {
        const nx = conf + d;
        setConf(nx);
        if (nx.length === 4) {
          if (pin === nx) { await savePIN(pin); onSuccess(); }
          else {
            setErr(t.pinMismatch);
            setTimeout(() => { setConf(""); setErr(""); setStep(1); setPin(""); }, 900);
          }
        }
      }
    }
  };

  const del = () => {
    if (mode === "check" || step === 1) setPin(p => p.slice(0,-1));
    else setConf(p => p.slice(0,-1));
  };

  const cur = mode === "check" ? pin : step === 1 ? pin : conf;

  return (
    <div style={{ minHeight:"100vh", background:"#0F0E0A", display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center", fontFamily:"'Cairo',sans-serif", direction:t.dir, padding:"0 32px" }}>
      <div style={{ position:"fixed", top:0, left:0, right:0, height:3, background:"linear-gradient(90deg,transparent,#C8973A,#F0C060,#C8973A,transparent)" }}/>
      <div style={{ fontSize:30, fontWeight:800, marginBottom:6, fontFamily:"'Playfair Display',serif", background:"linear-gradient(135deg,#F0C060,#C8973A)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>La Shawermeria</div>
      <div style={{ fontSize:12, color:"#C8973A", marginBottom:28, letterSpacing:2 }}>
        {mode==="set" ? (step===1 ? t.pinSetTitle : t.pinConfirm) : t.pinTitle}
      </div>
      <div style={{ display:"flex", gap:12, marginBottom:6 }}>
        {[0,1,2,3].map(i => (
          <div key={i} style={{ width:13, height:13, borderRadius:"50%", background: i < cur.length ? "#C8973A" : "rgba(200,151,58,0.18)", border:"1.5px solid rgba(200,151,58,0.35)", transition:"all 0.15s" }}/>
        ))}
      </div>
      {err      && <div style={{ fontSize:11, color:"#C84040", marginBottom:6 }}>{err}</div>}
      {checking && <div style={{ fontSize:10, color:"#C8973A", marginBottom:6 }}>...</div>}
      <div style={{ height:14 }}/>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:10, width:"100%", maxWidth:250 }}>
        {[1,2,3,4,5,6,7,8,9," ",0,"⌫"].map((d, i) => (
          <button key={i} onClick={() => d===" " ? null : d==="⌫" ? del() : tap(String(d))}
            style={{ padding:"17px", borderRadius:13, fontSize:19, fontWeight:700, fontFamily:"inherit", background: d===" " ? "transparent" : d==="⌫" ? "rgba(200,60,60,0.1)" : "rgba(255,255,255,0.05)", border: d===" " ? "none" : d==="⌫" ? "1px solid rgba(200,60,60,0.2)" : "1px solid rgba(255,255,255,0.08)", color: d==="⌫" ? "#C84040" : "#F0C060", cursor: d===" " ? "default" : "pointer", opacity: checking ? 0.5 : 1 }}>
            {d}
          </button>
        ))}
      </div>
      {mode==="set" && (
        <button onClick={onSkip} style={{ marginTop:20, background:"transparent", border:"none", color:"#504030", fontSize:11, cursor:"pointer", fontFamily:"inherit" }}>{t.pinSkip}</button>
      )}
    </div>
  );
}

/* ── Calendar Modal ── */
function CalModal({ t, isAr, sel, onSelect, onClose }) {
  const [vy, setVy]         = useState(sel.year);
  const [vm, setVm]         = useState(sel.month);
  const [pickMode, setPickMode] = useState(null);
  const n   = new Date();
  const dim = new Date(vy, vm, 0).getDate();
  const off = ((new Date(vy, vm-1, 1).getDay() - 1 + 7) % 7);
  const cells = [...Array(off).fill(null), ...Array.from({ length:dim }, (_, i) => i+1)];
  while (cells.length % 7) cells.push(null);

  const prev = () => vm===1 ? (setVm(12), setVy(y => y-1)) : setVm(m => m-1);
  const next = () => vm===12 ? (setVm(1), setVy(y => y+1)) : setVm(m => m+1);
  const years = Array.from({ length:10 }, (_, i) => n.getFullYear() - 4 + i);

  return (
    <div onClick={e => e.target===e.currentTarget && onClose()} style={{ position:"fixed", inset:0, zIndex:400, background:"rgba(0,0,0,0.75)", display:"flex", alignItems:"flex-end", justifyContent:"center", backdropFilter:"blur(4px)", direction:t.dir }} className="backdrop-blur">
      <div style={{ background:"#1A1810", borderTop:"2px solid #C8973A", borderRadius:"20px 20px 0 0", width:"100%", maxWidth:480, height:420, display:"flex", flexDirection:"column", padding:"14px 16px 32px" }}>
        <div style={{ width:34, height:4, background:"rgba(255,255,255,0.1)", borderRadius:2, margin:"0 auto 12px", flexShrink:0 }}/>
        {/* Header row */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginBottom:10, flexShrink:0 }}>
          <button onClick={onClose} style={{ ...btn("rgba(200,151,58,0.08)","rgba(200,151,58,0.25)","#C8973A",{padding:"0",width:32,height:32,fontSize:14}) }}>✕</button>
          <div style={{ display:"flex", alignItems:"center", gap:4 }}>
            <button onClick={prev} style={{ ...btn("rgba(200,151,58,0.08)","rgba(200,151,58,0.25)","#C8973A",{padding:"0",width:30,height:30,fontSize:16}) }}>‹</button>
            <button onClick={() => setPickMode(pickMode==="month" ? null : "month")} style={{ ...btn(pickMode==="month"?"rgba(200,151,58,0.2)":"rgba(200,151,58,0.06)","rgba(200,151,58,0.3)","#F0C060",{padding:"5px 10px",fontSize:12,fontWeight:900,minWidth:72,textAlign:"center"}) }}>{t.months[vm-1]}</button>
            <button onClick={() => setPickMode(pickMode==="year" ? null : "year")}  style={{ ...btn(pickMode==="year" ?"rgba(200,151,58,0.2)":"rgba(200,151,58,0.06)","rgba(200,151,58,0.3)","#F0C060",{padding:"5px 10px",fontSize:12,fontWeight:900,minWidth:52,textAlign:"center"}) }}>{vy}</button>
            <button onClick={next} style={{ ...btn("rgba(200,151,58,0.08)","rgba(200,151,58,0.25)","#C8973A",{padding:"0",width:30,height:30,fontSize:16}) }}>›</button>
          </div>
          <button onClick={() => { setVy(n.getFullYear()); setVm(n.getMonth()+1); setPickMode(null); }} style={{ ...btn("rgba(200,151,58,0.08)","rgba(200,151,58,0.25)","#C8973A",{padding:"0 10px",height:30,fontSize:10}) }}>{t.today}</button>
        </div>
        {/* Month picker */}
        {pickMode==="month" && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:6, marginBottom:10, flexShrink:0 }}>
            {t.months.map((mn, i) => (
              <button key={i} onClick={() => { setVm(i+1); setPickMode(null); }} style={{ ...btn(vm===i+1?"#C8973A":"rgba(255,255,255,0.04)", vm===i+1?"none":"rgba(255,255,255,0.07)", vm===i+1?"#0F0E0A":"#C0A070", {padding:"7px 2px",fontSize:10,fontWeight:700}) }}>{mn}</button>
            ))}
          </div>
        )}
        {/* Year picker */}
        {pickMode==="year" && (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(5,1fr)", gap:6, marginBottom:10, flexShrink:0 }}>
            {years.map(yr => (
              <button key={yr} onClick={() => { setVy(yr); setPickMode(null); }} style={{ ...btn(vy===yr?"#C8973A":"rgba(255,255,255,0.04)", vy===yr?"none":"rgba(255,255,255,0.07)", vy===yr?"#0F0E0A":"#C0A070", {padding:"7px 2px",fontSize:11,fontWeight:700}) }}>{yr}</button>
            ))}
          </div>
        )}
        {/* Calendar grid */}
        {!pickMode && (
          <>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:3, marginBottom:6, flexShrink:0 }}>
              {t.daysShort.map((d, i) => (
                <div key={i} style={{ textAlign:"center", fontSize:9, fontWeight:700, color: i>=5?"#C8973A":"#506050", padding:"2px 0" }}>{d}</div>
              ))}
            </div>
            <div style={{ display:"grid", gridTemplateColumns:"repeat(7,1fr)", gap:4, flex:1 }}>
              {cells.map((d, i) => {
                const isTod = d && d===n.getDate() && vm===n.getMonth()+1 && vy===n.getFullYear();
                const isSel = d && d===sel.day && vm===sel.month && vy===sel.year;
                return (
                  <div key={i} onClick={() => d && onSelect({ year:vy, month:vm, day:d })} style={{ borderRadius:8, display:"flex", alignItems:"center", justifyContent:"center", fontSize:13, fontWeight: isSel||isTod ? 900 : 500, cursor: d ? "pointer" : "default", background: isSel ? "#C8973A" : isTod ? "rgba(200,151,58,0.2)" : d ? "rgba(255,255,255,0.03)" : "transparent", border: isSel ? "none" : isTod ? "1.5px solid #C8973A" : d ? "1px solid rgba(255,255,255,0.06)" : "none", color: isSel ? "#0F0E0A" : isTod ? "#F0C060" : i%7>=5 ? "#C8973A" : d ? "#D0C0A0" : "transparent" }}>
                    {d || ""}
                  </div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

/* ── Amount Modal (generic) ── */
function AmountModal({ label, icon, color, current, currentNote, branches, activeBranch, getBN, onSave, onClose, t }) {
  const [val, setVal]     = useState(current > 0 ? String(current) : "");
  const [notes, setNotes] = useState(() => {
    const n = currentNote || "";
    return n ? n.split(" | ").filter(Boolean) : [""];
  });
  const needBranch    = !activeBranch && branches.length > 1;
  const [targetBranch, setTargetBranch] = useState(activeBranch || branches[0]?.id);
  const joinedNote = notes.filter(n => n.trim()).join(" | ");

  return (
    <div onClick={e => e.target===e.currentTarget && onClose()} style={{ position:"fixed", inset:0, zIndex:500, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"flex-end", justifyContent:"center", backdropFilter:"blur(6px)" }} className="backdrop-blur">
      <div style={{ background:"#1A1810", borderTop:`2px solid ${color}`, borderRadius:"20px 20px 0 0", padding:"24px 20px 44px", width:"100%", maxWidth:480, maxHeight:"90vh", overflowY:"auto" }}>
        <div style={{ width:34, height:4, background:"rgba(255,255,255,0.08)", borderRadius:2, margin:"0 auto 16px" }}/>
        <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:16 }}>
          <span style={{ fontSize:24 }}>{icon}</span>
          <span style={{ fontSize:15, fontWeight:800, color:"#F5EDD6" }}>{label}</span>
        </div>
        {needBranch && (
          <div style={{ marginBottom:14 }}>
            <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>{t.selectBranch}</div>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {branches.map(b => (
                <button key={b.id} onClick={() => setTargetBranch(b.id)} style={{ padding:"6px 12px", borderRadius:20, fontFamily:"inherit", fontSize:11, fontWeight:700, cursor:"pointer", border: targetBranch===b.id?`1.5px solid ${b.color}`:"1px solid rgba(255,255,255,0.1)", background: targetBranch===b.id?`${b.color}22`:"rgba(255,255,255,0.04)", color: targetBranch===b.id?b.color:"#706050" }}>
                  {b.icon} {getBN(b)}
                </button>
              ))}
            </div>
          </div>
        )}
        <div style={{ position:"relative", marginBottom:10 }}>
          <input autoFocus type="text" inputMode="decimal" value={val} onChange={e => setVal(toWesternNumerals(e.target.value))} onKeyDown={e => e.key==="Enter" && onSave(parseFloat(val)||0, joinedNote, targetBranch)} placeholder={t.enterAmount} style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:22, fontWeight:800, border:`1.5px solid ${color}50` }}/>
          <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
        </div>
        <NotesField notes={notes} onChange={setNotes} t={t} accentColor={`${color}40`}/>
        <div style={{ display:"flex", gap:9 }}>
          <button onClick={() => onSave(parseFloat(val)||0, joinedNote, targetBranch)} style={{ ...btn(`linear-gradient(135deg,${color},${color}99)`,"none","#0F0E0A",{flex:1,border:"none"}) }}>{t.save} ✓</button>
          <button onClick={onClose} style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 16px"}) }}>{t.cancel}</button>
        </div>
      </div>
    </div>
  );
}

/* ── Glovo Modal ── */
function GlovoModal({ data, currentDateKey, branches, activeBranch, onSave, onClose, t, isAr }) {
  const defaultBranch = activeBranch || branches[0]?.id;
  const [targetBranch, setTargetBranch] = useState(defaultBranch);
  const [grossSales, setGrossSales]     = useState("");
  const [netPayout,  setNetPayout]      = useState("");
  const [notes, setNotes]               = useState([""]);

  const currentSalesData = useMemo(
    () => data[targetBranch]?.[currentDateKey]?.sales,
    [data, targetBranch, currentDateKey]
  );

  useEffect(() => {
    setGrossSales(currentSalesData?.glovo ? String(currentSalesData.glovo) : "");
    setNetPayout (currentSalesData?.glovo_net ? String(currentSalesData.glovo_net) : "");
    const saved = currentSalesData?.glovo_note || "";
    setNotes(saved ? saved.split(" | ").filter(Boolean) : [""]);
  }, [targetBranch, currentDateKey, currentSalesData]);

  const gross          = parseFloat(grossSales) || 0;
  const net            = parseFloat(netPayout)  || 0;
  const glovoCommission = gross - net;
  const netPercentage  = gross > 0 ? ((net / gross) * 100).toFixed(1) : 0;
  const commissionPct  = gross > 0 ? ((glovoCommission / gross) * 100).toFixed(1) : 0;
  const commStatus     = gross===0 ? {color:"#504030",text:"-"} : commissionPct<=35 ? {color:"#3AC87D",text:t.ratioExcellent} : commissionPct<=45 ? {color:"#C8C03A",text:t.ratioWarning} : {color:"#C83A3A",text:t.ratioDanger};

  const handleSave = () => {
    if (gross <= 0) { alert(t.enterGrossSales); return; }
    if (net < 0 || net > gross) { alert(t.invalidNetPayout); return; }
    onSave(gross, net, notes.filter(n => n.trim()).join(" | "), targetBranch);
  };

  return (
    <div onClick={e => e.target===e.currentTarget && onClose()} style={{ position:"fixed", inset:0, zIndex:500, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"flex-end", justifyContent:"center", backdropFilter:"blur(6px)" }} className="backdrop-blur">
      <div style={{ background:"#1A1810", borderTop:"2px solid #FF6B00", borderRadius:"20px 20px 0 0", padding:"24px 20px 44px", width:"100%", maxWidth:480, maxHeight:"90vh", overflowY:"auto" }}>
        <div style={{ width:34, height:4, background:"rgba(255,255,255,0.08)", borderRadius:2, margin:"0 auto 16px" }}/>
        <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:20 }}>
          <span style={{ fontSize:24 }}>🟡</span>
          <span style={{ fontSize:16, fontWeight:800, color:"#F5EDD6" }}>Glovo - {t.onlineSales}</span>
        </div>
        {/* Branch selector */}
        {!activeBranch && branches.length > 1 && (
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>{t.selectBranch}</div>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {branches.map(b => (
                <button key={b.id} onClick={() => setTargetBranch(b.id)} style={{ padding:"6px 12px", borderRadius:20, fontFamily:"inherit", fontSize:11, fontWeight:700, cursor:"pointer", border: targetBranch===b.id?`1.5px solid ${b.color}`:"1px solid rgba(255,255,255,0.1)", background: targetBranch===b.id?`${b.color}22`:"rgba(255,255,255,0.04)", color: targetBranch===b.id?b.color:"#706050" }}>
                  {b.icon} {b.nameEn}
                </button>
              ))}
            </div>
          </div>
        )}
        {/* Gross */}
        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>💰 {t.grossSales}</div>
          <div style={{ position:"relative" }}>
            <input autoFocus type="text" inputMode="decimal" value={grossSales} onChange={e => setGrossSales(toWesternNumerals(e.target.value))} placeholder="0.00" style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:20, fontWeight:800, border:"1.5px solid #FF6B00", background:"rgba(255,107,0,0.05)" }}/>
            <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
          </div>
          <div style={{ textAlign:"left", marginTop:4, fontSize:11, color:"#FF6B00", fontWeight:700 }}>100%</div>
        </div>
        {/* Net */}
        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>🏦 {t.netPayout}</div>
          <div style={{ position:"relative" }}>
            <input type="text" inputMode="decimal" value={netPayout} onChange={e => setNetPayout(toWesternNumerals(e.target.value))} placeholder="0.00" style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:20, fontWeight:800, border:"1.5px solid #3AC87D", background:"rgba(58,200,125,0.05)" }}/>
            <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
          </div>
          {gross > 0 && <div style={{ textAlign:"left", marginTop:4, fontSize:11, color:"#3AC87D", fontWeight:700 }}>{netPercentage}% {t.ofTotal}</div>}
        </div>
        {/* Commission summary */}
        <div style={{ marginBottom:16, padding:"12px", background:"rgba(255,107,0,0.08)", border:"1px solid rgba(255,107,0,0.3)", borderRadius:10 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>📊 {t.glovoCommission} <span style={{ fontSize:9, color:"#605040" }}>({t.autoCalculated})</span></div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:18, fontWeight:800, color:"#FF6B00" }} className="western-numerals">{gross > 0 ? fmt(glovoCommission) : "0.00 €"}</span>
            {gross > 0 && (
              <span style={{ fontSize:12, fontWeight:700, color:commStatus.color, padding:"4px 10px", background:`${commStatus.color}20`, borderRadius:6, border:`1px solid ${commStatus.color}40` }} className="western-numerals">{commissionPct}% • {commStatus.text}</span>
            )}
          </div>
        </div>
        <NotesField notes={notes} onChange={setNotes} t={t} accentColor="rgba(255,107,0,0.35)"/>
        <div style={{ display:"flex", gap:9 }}>
          <button onClick={handleSave} style={{ ...btn("linear-gradient(135deg,#FF6B00,#E55A00)","none","#0F0E0A",{flex:1,border:"none",fontSize:14}) }}>{t.save} ✓</button>
          <button onClick={onClose}   style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 16px",fontSize:14}) }}>{t.cancel}</button>
        </div>
      </div>
    </div>
  );
}

/* ── Uber Eats Modal ── */
function UberEatsModal({ data, currentDateKey, branches, activeBranch, onSave, onClose, t, isAr }) {
  const defaultBranch = activeBranch || branches[0]?.id;
  const [targetBranch, setTargetBranch] = useState(defaultBranch);
  const [grossSales,   setGrossSales]   = useState("");
  const [netPayout,    setNetPayout]    = useState("");
  const [adCost,       setAdCost]       = useState("");
  const [notes, setNotes]               = useState([""]);

  const currentSalesData = useMemo(
    () => data[targetBranch]?.[currentDateKey]?.sales,
    [data, targetBranch, currentDateKey]
  );

  useEffect(() => {
    setGrossSales(currentSalesData?.uberEats    ? String(currentSalesData.uberEats)    : "");
    setNetPayout (currentSalesData?.uberEats_net ? String(currentSalesData.uberEats_net): "");
    setAdCost    (currentSalesData?.uberEats_ad  ? String(currentSalesData.uberEats_ad) : "");
    const saved = currentSalesData?.uberEats_note || "";
    setNotes(saved ? saved.split(" | ").filter(Boolean) : [""]);
  }, [targetBranch, currentDateKey, currentSalesData]);

  const gross      = parseFloat(grossSales) || 0;
  const net        = parseFloat(netPayout)  || 0;
  const ad         = parseFloat(adCost)     || 0;
  const commission = gross - net - ad;
  const totalCut   = commission + ad;

  const netPct      = gross > 0 ? ((net / gross) * 100).toFixed(1) : 0;
  const commPct     = gross > 0 ? ((commission / gross) * 100).toFixed(1) : 0;
  const adPct       = gross > 0 ? ((ad / gross) * 100).toFixed(1) : 0;
  const totalCutPct = gross > 0 ? ((totalCut / gross) * 100).toFixed(1) : 0;
  const isInvalid   = gross > 0 && (gross < net + ad);

  const commStatus     = (gross===0||commission<0) ? {color:"#504030",text:"-"} : commPct<=30 ? {color:"#3AC87D",text:t.ratioExcellent} : commPct<=40 ? {color:"#C8C03A",text:t.ratioWarning} : {color:"#C83A3A",text:t.ratioDanger};
  const adStatus       = (gross===0||ad===0)       ? {color:"#504030",text:"-"} : adPct<=5    ? {color:"#3AC87D",text:t.ratioExcellent} : adPct<=10   ? {color:"#C8C03A",text:t.ratioWarning} : {color:"#C83A3A",text:t.ratioDanger};
  const totalCutStatus = (gross===0||totalCut<0)   ? {color:"#504030",text:"-"} : totalCutPct<=30 ? {color:"#3AC87D",text:t.ratioExcellent} : totalCutPct<=40 ? {color:"#C8C03A",text:t.ratioWarning} : {color:"#C83A3A",text:t.ratioDanger};

  const handleSave = () => {
    if (gross <= 0) { alert(t.enterGrossSales); return; }
    if (net < 0)    { alert(t.invalidNetPayout); return; }
    if (gross < net+ad) { alert(t.uberInvalidNumbers); return; }
    onSave(gross, net, ad, notes.filter(n => n.trim()).join(" | "), targetBranch);
  };

  return (
    <div onClick={e => e.target===e.currentTarget && onClose()} style={{ position:"fixed", inset:0, zIndex:500, background:"rgba(0,0,0,0.85)", display:"flex", alignItems:"flex-end", justifyContent:"center", backdropFilter:"blur(6px)" }} className="backdrop-blur">
      <div style={{ background:"#1A1810", borderTop:"2px solid #06C167", borderRadius:"20px 20px 0 0", padding:"24px 20px 44px", width:"100%", maxWidth:480, overflowY:"auto", maxHeight:"92vh" }}>
        <div style={{ width:34, height:4, background:"rgba(255,255,255,0.08)", borderRadius:2, margin:"0 auto 16px" }}/>
        <div style={{ display:"flex", alignItems:"center", gap:9, marginBottom:6 }}>
          <span style={{ fontSize:24 }}>🚗</span>
          <span style={{ fontSize:16, fontWeight:800, color:"#F5EDD6" }}>Uber Eats - {t.onlineSales}</span>
        </div>
        <div style={{ marginBottom:16, padding:"8px 12px", background:"rgba(200,151,58,0.08)", border:"1px solid rgba(200,151,58,0.2)", borderRadius:8, textAlign:"center" }}>
          <div style={{ fontSize:10, color:"#C8973A", fontWeight:700 }}>📐 {t.uberFormula}</div>
        </div>
        {/* Branch selector */}
        {!activeBranch && branches.length > 1 && (
          <div style={{ marginBottom:16 }}>
            <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>{t.selectBranch}</div>
            <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
              {branches.map(b => (
                <button key={b.id} onClick={() => setTargetBranch(b.id)} style={{ padding:"6px 12px", borderRadius:20, fontFamily:"inherit", fontSize:11, fontWeight:700, cursor:"pointer", border: targetBranch===b.id?`1.5px solid ${b.color}`:"1px solid rgba(255,255,255,0.1)", background: targetBranch===b.id?`${b.color}22`:"rgba(255,255,255,0.04)", color: targetBranch===b.id?b.color:"#706050" }}>
                  {b.icon} {b.nameEn}
                </button>
              ))}
            </div>
          </div>
        )}
        {isInvalid && (
          <div style={{ marginBottom:12, padding:"8px 12px", background:"rgba(200,60,60,0.12)", border:"1px solid rgba(200,60,60,0.3)", borderRadius:8, textAlign:"center" }}>
            <div style={{ fontSize:11, color:"#C84040", fontWeight:700 }}>⚠️ {t.uberInvalidNumbers}</div>
          </div>
        )}
        {/* Gross */}
        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>💰 {t.uberGrossSales}</div>
          <div style={{ position:"relative" }}>
            <input autoFocus type="text" inputMode="decimal" value={grossSales} onChange={e => setGrossSales(toWesternNumerals(e.target.value))} placeholder="0.00" style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:20, fontWeight:800, border:"1.5px solid #06C167", background:"rgba(6,193,103,0.05)" }}/>
            <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
          </div>
          <div style={{ textAlign:"left", marginTop:4, fontSize:11, color:"#06C167", fontWeight:700 }}>100%</div>
        </div>
        {/* Ads */}
        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>📣 {isAr?"تكلفة الدعاية (Ads)":"Ad Cost (Ads)"}</div>
          <div style={{ position:"relative" }}>
            <input type="text" inputMode="decimal" value={adCost} onChange={e => setAdCost(toWesternNumerals(e.target.value))} placeholder="0.00" style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:20, fontWeight:800, border:"1.5px solid #C8973A", background:"rgba(200,151,58,0.05)" }}/>
            <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
          </div>
          {gross>0 && ad>0 && (
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", marginTop:5 }}>
              <div style={{ fontSize:11, color:"#C8973A", fontWeight:700 }} className="western-numerals">{adPct}% {t.ofTotal}</div>
              <span style={{ fontSize:11, fontWeight:700, color:adStatus.color, padding:"2px 8px", background:`${adStatus.color}18`, borderRadius:5, border:`1px solid ${adStatus.color}35` }}>{adStatus.text}</span>
            </div>
          )}
        </div>
        {/* Net */}
        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>🏦 {t.uberNetPayout}</div>
          <div style={{ position:"relative" }}>
            <input type="text" inputMode="decimal" value={netPayout} onChange={e => setNetPayout(toWesternNumerals(e.target.value))} placeholder="0.00" style={{ ...inputStyle("ltr"), padding:"13px 52px 13px 14px", fontSize:20, fontWeight:800, border:"1.5px solid #3AC87D", background:"rgba(58,200,125,0.05)" }}/>
            <span style={{ position:"absolute", top:"50%", right:14, transform:"translateY(-50%)", color:"#706050", fontSize:14, fontWeight:700 }}>€</span>
          </div>
          {gross>0 && <div style={{ textAlign:"left", marginTop:4, fontSize:11, color:"#3AC87D", fontWeight:700 }} className="western-numerals">{netPct}% {t.ofTotal}</div>}
        </div>
        {/* Commission */}
        <div style={{ marginBottom:10, padding:"12px", background:`rgba(${commission<0?"200,60,60":"6,193,103"},0.08)`, border:`1px solid rgba(${commission<0?"200,60,60":"6,193,103"},0.3)`, borderRadius:10 }}>
          <div style={{ fontSize:10, color:"#806030", marginBottom:6 }}>📊 {t.uberCommission} <span style={{ fontSize:9, color:"#605040" }}>({t.autoCalculated})</span></div>
          <div style={{ fontSize:9, color:"#605040", marginBottom:8 }}>
            <span className="western-numerals">{fmt(gross)}</span> − <span className="western-numerals">{fmt(net)}</span> − <span className="western-numerals">{fmt(ad)}</span> = <strong style={{ color: commission<0?"#C84040":"#06C167" }} className="western-numerals">{fmt(commission)}</strong>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:18, fontWeight:800, color: commission<0?"#C84040":"#06C167" }} className="western-numerals">{gross>0 ? fmt(commission) : "0.00 €"}</span>
            {gross>0 && commission>=0 && (
              <span style={{ fontSize:12, fontWeight:700, color:commStatus.color, padding:"4px 10px", background:`${commStatus.color}20`, borderRadius:6, border:`1px solid ${commStatus.color}40` }} className="western-numerals">{commPct}% • {commStatus.text}</span>
            )}
          </div>
        </div>
        {/* Total cut */}
        <div style={{ marginBottom:16, padding:"12px", background:`rgba(${totalCut<0?"200,60,60":"139,58,200"},0.1)`, border:`1px solid rgba(${totalCut<0?"200,60,60":"139,58,200"},0.35)`, borderRadius:10 }}>
          <div style={{ fontSize:10, color:"#C090F0", marginBottom:6, fontWeight:700 }}>📊 {t.uberTotalCut} <span style={{ fontSize:9, color:"#605040", fontWeight:400 }}>({t.autoCalculated})</span></div>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center" }}>
            <span style={{ fontSize:18, fontWeight:800, color: totalCut<0?"#C84040":"#C090F0" }} className="western-numerals">{gross>0 ? fmt(totalCut) : "0.00 €"}</span>
            {gross>0 && totalCut>=0 && (
              <span style={{ fontSize:12, fontWeight:700, color:totalCutStatus.color, padding:"4px 10px", background:`${totalCutStatus.color}20`, borderRadius:6, border:`1px solid ${totalCutStatus.color}40` }} className="western-numerals">{totalCutPct}% • {totalCutStatus.text}</span>
            )}
          </div>
        </div>
        <NotesField notes={notes} onChange={setNotes} t={t} accentColor="rgba(6,193,103,0.35)"/>
        <div style={{ display:"flex", gap:9 }}>
          <button onClick={handleSave} disabled={isInvalid} style={{ ...btn("linear-gradient(135deg,#06C167,#059951)","none","#0F0E0A",{flex:1,border:"none",fontSize:14,opacity:isInvalid?0.5:1}) }}>{t.save} ✓</button>
          <button onClick={onClose}   style={{ ...btn("rgba(255,255,255,0.04)","rgba(255,255,255,0.08)","#706050",{padding:"11px 16px",fontSize:14}) }}>{t.cancel}</button>
        </div>
      </div>
    </div>
  );
}
