/* ═══════════════════════════════════════════
   constants.js — App Config & Helpers
   ═══════════════════════════════════════════ */

const COLORS = [
  "#C8973A", "#3A7DC8", "#C83A3A", "#3AC87D",
  "#8B3AC8", "#C83A8B", "#3AC8C8", "#C8683A"
];

const INIT_BRANCHES = [
  { id: 1, nameEn: "Lasha 1",  color: "#C8973A", icon: "🏪" },
  { id: 2, nameEn: "La Sha 2", color: "#3A7DC8", icon: "🏬" },
];

const DEFAULT_REPORT_CONFIG = {
  hideZeroItems:         true,
  excludeZeroDays:       false,
  groupSmallExpenses:    false,
  smallExpenseThreshold: 50,
  showKPIs:              true,
  showComparison:        true,
  showCharts:            true,
  showBranchAnalysis:    true,
  showPlatformAnalysis:  true,
  salesTarget:           0,
  branchSort:            'profit',
  itemSort:              'value_desc',
  printMode:             'light',
  showPercentages:       true,
  showIcons:             true,
  showCurrency:          true,
  watermark:             'none',
  showManualNotes:       false,
  manualNotesText:       ''
};

/* ── Helpers ── */
function toWesternNumerals(text) {
  if (!text) return text;
  return text.toString()
    .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
    .replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)));
}

const fmt = (n, showCurrency = true) => {
  const val = `${n < 0 ? "-" : ""}${Math.abs(n).toLocaleString('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  })}`;
  return showCurrency ? `${val} €` : val;
};

const dKey = (y, m, d) =>
  `${y}-${String(m).padStart(2,"0")}-${String(d).padStart(2,"0")}`;

function getTodayKey() {
  const n = new Date();
  return dKey(n.getFullYear(), n.getMonth() + 1, n.getDate());
}

function getActiveKey(dateFilter, selDate) {
  if (dateFilter === "custom") return dKey(selDate.year, selDate.month, selDate.day);
  return getTodayKey();
}

const now = () => {
  const n = new Date();
  return { year: n.getFullYear(), month: n.getMonth() + 1, day: n.getDate() };
};

const load = (k, def) => {
  try {
    const v = localStorage.getItem(k);
    return v ? JSON.parse(v) : def;
  } catch { return def; }
};

/* ── Shared Style Helpers ── */
const btn = (bg, border, color, extra = {}) => ({
  padding: "10px 14px",
  background: bg,
  border: `1px solid ${border}`,
  borderRadius: 8,
  color,
  fontSize: 12,
  fontWeight: 700,
  fontFamily: "inherit",
  cursor: "pointer",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  gap: 6,
  ...extra
});

const inputStyle = (dir = "rtl") => ({
  width: "100%",
  padding: "11px 14px",
  background: "rgba(255,255,255,0.05)",
  border: "1px solid rgba(200,151,58,0.28)",
  borderRadius: 10,
  color: "#F5EDD6",
  fontSize: 14,
  fontFamily: "inherit",
  outline: "none",
  boxSizing: "border-box",
  direction: dir
});

const getRatioColor  = r => r < 30 ? "#3AC87D" : r < 40 ? "#C8C03A" : "#C83A3A";
const getRatioStatus = (r, t) =>
  r < 30 ? t.ratioExcellent : r < 40 ? t.ratioWarning : t.ratioDanger;
